[] adjustIllMultiTableForSave()
[] adjustMaskBendParticleInspectionTab()
[] adjustOASTab()
[] adjustPlateAATab()
[] adjustPlateAfcTab()
[] adjustProcessControlTab()
[] checkDuplicateSetCode()
[] checkMxCompModeChange()
[] checkOASBaseLineMeasurementShot(String, String, Map<String, AbstractConsoleData>, Map<String, AbstractConsoleData>)
[] checkOASJobExecute(Map<String, AbstractConsoleData>, Map<String, AbstractConsoleData>, String, String)
[] checkOASZeroLayerTabParameterError()
[] controlAFCProc()
[] controlAllShotAFCItem()
[] controlLastShotAFC()
[] controlOASFocusInterlock()
[] controlPlateFocusInterlock()
[] forceChangeBarmirrorMagnificationBase()
[] forceChangeForOASLayout()
[] forceChangeMeasurementParameter()
[] forceChangeOASBasePlateTVAACenterPosition()
[] forceChangeOASZSensorOffsetMeasurement()
[] forceValueForMaskLayoutVSCP()
[] forceValueForOpti50()
[] getADCMode()
[] getASFDC()
[] getCalcJobErrorSetCodeMap()
[] getConsDouble(String)
[] getConsLong(String)
[] getDeviceConsData(String)
[] getOffsetZeroSetCode(int)
[COVERED] getProcessConsData(String)
[] getStepNo()
[] getStepNum()
[] getXStepNum()
[] getYStepNum()
[] initialize()
[] isChangeOASLayout(Map<String, AbstractConsoleData>)
[] isChangeOASMeasurementSetting(Map<String, AbstractConsoleData>)
[] isEdgeModeAFCFast()
[] isOASEachShotAFCAveCompEnable()
[] isOASParanemic()
[] isOASZeroLayerMarkAlignmentOrAmfMeas()
[] isSmallAlignmentMark()
[] isTwoBendUse()
[] performValueRangeCheck()
[] prepareDataForValidation()
[] setConsDataValue(String, String)
[] setForceEdgeModeAFCFastOff()
[] updateDefocusMeasureInterval()
[] updateOASZMeasHomeSensorOffset()


public APIs:
ProcessDataRecipeValidator()           <------ COVERED
ProcessDataRecipeValidator(boolean)

[2] isChangeOASLayout(Map<String, AbstractConsoleData>)
[2] isChangeOASMeasurementSetting(Map<String, AbstractConsoleData>)
[2] isEdgeModeAFCFast()
[3: 1 Invalid; 2 Valid] performCheckValueWrong(long, boolean, boolean, Map<String, AbstractConsoleData>)
[2] performCalcJobForProcess(String, String, Map<String, AbstractConsoleData>, Map<String, AbstractConsoleData>)

[1: Invalid] validateProcessDataRecipe:checkDuplicateSetCode()


TODO:

1. Update implementation: ProcessDataRecipeValidator:performCheckValueWrong() --> same with DeviceDataRecipeValidator:performCheckValueWrong()
	* Commit to GUIRefactoring_5872 branch

2. In ProcessData/DeviceDataRecipeValidator, move convertAbstractConsoleDataToConsBase() to AbstractCommonRecipeValidator class
	* Commit to GUIRefactoring_5872 branch

3. TestCode: test_performCheckValueWrong_Valid_002 @ DeviceDataRecipeValidator, remove @throws RemoteException 
