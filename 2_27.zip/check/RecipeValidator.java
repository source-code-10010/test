/*-----------------------------------------------------------
 - �X�}�[�g�R���\�[��(Smart Console)						-
 - 		Console software for MPAsp series.					-
 -															-
 - FPD Production Equipment PLM Center 4					-
 - Copyright (C) 2009 - 2018 Canon Inc. All Rights Reserved	-
 ------------------------------------------------------------*/
package canon.lcd.console.service.recipe.check;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import canon.lcd.console.service.AbstractConsoleData;
import canon.lcd.console.service.recipe.ConsoleRecipeInfoManagerAccessIF;
import canon.lcd.console.serviceFactory.NameService;

/**
 * Common Recipe validator for DeviceData and ProcessData.
 */
public class RecipeValidator {

	/**
	 * DeviceDataRecipeValidator instance.
	 */
	private DeviceDataRecipeValidator m_DeviceRecipeValidator = null;

	/**
	 * ProcessDataRecipeValidator instance.
	 */
	private ProcessDataRecipeValidator m_ProcessRecipeValidator = null;

	/**
	 * RecipeValidator constructor.
	 *
	 */
	public RecipeValidator() {
		m_DeviceRecipeValidator = new DeviceDataRecipeValidator();
		m_ProcessRecipeValidator = new ProcessDataRecipeValidator();
	}

	/**
	 * Validates DeviceData and ProcessData recipe.
	 *
	 * @param sDeviceName Device name
	 * @param sProcessName Process name
	 * @return RecipeDataError
	 */
	public Map<String, List<String>> validateRecipe(final String sDeviceName, final String sProcessName) {
		final ConsoleRecipeInfoManagerAccessIF recipeInfo =
				NameService.getConsoleServiceFactory().getRecipeInfoAccessService();
		final Map<String, List<String>> mRecipeDataError = new HashMap<String, List<String>>();

		// Perform validation for both Device Data and Process Data
		final Map<String, AbstractConsoleData> mapProcessData =
				recipeInfo.getAllProcessData(sDeviceName, sProcessName);
		final Map<String, AbstractConsoleData> mapDeviceData =
				recipeInfo.getAllDeviceData(sDeviceName);

		mRecipeDataError.putAll(m_ProcessRecipeValidator.validateProcessDataRecipe(mapProcessData,
				mapDeviceData, sDeviceName, sProcessName));
		mRecipeDataError.putAll(m_DeviceRecipeValidator.validateDeviceDataRecipe(mapDeviceData,
				sDeviceName, sProcessName));

		return mRecipeDataError;
	}
}
