/*-----------------------------------------------------------
 - �X�}�[�g�R���\�[��(Smart Console)						-
 - 		Console software for MPAsp series.					-
 -															-
 - FPD Production Equipment PLM Center 4					-
 - Copyright (C) 2009 - 2018 Canon Inc. All Rights Reserved	-
 ------------------------------------------------------------*/
package canon.lcd.console.service.recipe.check;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import canon.lcd.console.service.AbstractConsoleData;
import canon.lcd.console.service.ConsoleDataDouble;
import canon.lcd.console.service.ConsoleDataLong;
import canon.lcd.console.service.ConsoleDataString;
import canon.lcd.console.service.funcchecker.FunctionCheckerIF;
import canon.lcd.console.service.funcchecker.checker.EdgeModeAFCFastChecker;
import canon.lcd.console.service.funcchecker.checker.FullShotAASearchChecker;
import canon.lcd.console.service.funcchecker.checker.H800Checker;
import canon.lcd.console.service.funcchecker.checker.OASEachShotAFCAveCompChecker;
import canon.lcd.console.service.funcchecker.checker.OASFDCChecker;
import canon.lcd.console.service.funcchecker.checker.OASLEDRedChecker;
import canon.lcd.console.service.funcchecker.checker.OASLEDRedE813Checker;
import canon.lcd.console.service.funcchecker.checker.OASUnitTypeParanemicChecker;
import canon.lcd.console.service.funcchecker.checker.OASUnitTypeShotMoveChecker;
import canon.lcd.console.service.funcchecker.checker.OASZeroLayerChecker;
import canon.lcd.console.service.funcchecker.checker.ShotChoiceExposureChecker;
import canon.lcd.console.service.funcchecker.checker.SlitMaskingBladeChecker;
import canon.lcd.console.service.funcchecker.checker.XSlitMaskingBladeChecker;
import canon.lcd.console.service.recipe.JobCalculationManagerAccessServiceIF;
import canon.lcd.console.service.recipe.JobEditConst;
import canon.lcd.console.service.recipe.RecipeConst;
import canon.lcd.console.service.recipe.ValueWrongCheckProxy;
import canon.lcd.console.service.recipe.impl.calc.AbstractCalcJob;
import canon.lcd.console.service.recipe.impl.calc.paranemicoas.ConfinedVSOasXPositionCalculator;
import canon.lcd.console.service.recipe.JobParameterTableData.SETCODE;
import canon.lcd.console.service.recipe.oas.MeasurementSettingData;
import canon.lcd.console.service.recipe.oas.OasTabConst;
import canon.lcd.console.service.recipe.oas.MeasurementSettingData.LineSettingSetCode;
import canon.lcd.console.service.recipe.oas.OASLayoutData.OASLayoutSetCode;
import canon.lcd.console.service.recipe.oas.OasTabConst.ConditionPanelSetCode;
import canon.lcd.console.serviceFactory.NameService;
import canon.lcd.console.utility.CommonUtil;
import canon.lcd.g10lib.utility.log.ConsoleLogger;


/**
 * Class that validates Process Data Recipe.
 */
public class ProcessDataRecipeValidator extends AbstractCommonRecipeValidator {

	/**
	 * Consistency check instance (For ProcessDataRecipeValidator, instance is ConsistencyCheckForProcess).
	 */
	private ConsistencyCheckIF m_ConsistencyCheck = null;

	/**
	 * Job Calculation Manager Access Service instance.
	 */
	private JobCalculationManagerAccessServiceIF m_JobCalculationManagerAccessService = null;

	/**
	 * Function Checker instance.
	 */
	private FunctionCheckerIF m_FunctionChecker = null;

	/**
	 * Check if for multi commmon process.
	 */
	private boolean m_IsMultiCommonProcess = false;

	/**
	 * Contains mapping of setcode and value for ProcessData.
	 */
	private Map<String, AbstractConsoleData> m_mapConsDataForProcess = null;

	/**
	 * Contains mapping of setcode and value for DeviceData.
	 */
	private Map<String, AbstractConsoleData> m_mapConsDataForDevice = null;

	/**
	 * Offset zero setcode that has validation error.
	 */
	private final List<String> m_sErrorOffsetZeroSetCode = new ArrayList<String>();

	/**
	 * DeviceData name.
	 */
	private String m_sDeviceName = null;
	
	/**
	 * ProcessData name.
	 */
	private String m_sProcessName = null;

	/**
	 * ADC Offset Setcode.
	 */
	public enum ADCOffsetSetCode {	
		/**
		 * P1 XL SetCode.
		 */	
		ADC_OFFSET_P1_XL("12060", 0xC),
		/**
		 * P1 YL SetCode.
		 */	
		ADC_OFFSET_P1_YL("12061", 0xC),
		/**
		 * P1 XR SetCode.
		 */	
		ADC_OFFSET_P1_XR("12062", 0xC),
		/**
		 * P1 YR SetCode.
		 */	
		ADC_OFFSET_P1_YR("12063", 0xC),
		/**
		 * P2P1 XL SetCode.
		 */	
		SUB_OFFSET_P2P1_XL("23400", 0x8),
		/**
		 * P2P1 YL SetCode.
		 */	
		SUB_OFFSET_P2P1_YL("23401", 0x8),
		/**
		 * P2P1 XR SetCode.
		 */	
		SUB_OFFSET_P2P1_XR("23402", 0x8),
		/**
		 * P2P1 YR SetCode.
		 */	
		SUB_OFFSET_P2P1_YR("23403", 0x8),
		/**
		 * P2 XL SetCode.
		 */	
		ADC_OFFSET_P2_XL("12064", 0xC),
		/**
		 * P2 YL SetCode.
		 */	
		ADC_OFFSET_P2_YL("12065", 0xC),
		/**
		 * P2 XR SetCode.
		 */	
		ADC_OFFSET_P2_XR("12066", 0xC),
		/**
		 * P2 YR SetCode.
		 */	
		ADC_OFFSET_P2_YR("12067", 0xC),
		/**
		 * P2P3 XL SetCode.
		 */	
		SUB_OFFSET_P2P3_XL("23404", 0x8),
		/**
		 * P2P3 YL SetCode.
		 */	
		SUB_OFFSET_P2P3_YL("23405", 0x8),
		/**
		 * P2P3 XR SetCode.
		 */	
		SUB_OFFSET_P2P3_XR("23406", 0x8),
		/**
		 * P2P3 YR SetCode.
		 */	
		SUB_OFFSET_P2P3_YR("23407", 0x8),
		/**
		 * P3 XL SetCode.
		 */	
		ADC_OFFSET_P3_XL("12068", 0xC),
		/**
		 * P3 YL SetCode.
		 */	
		ADC_OFFSET_P3_YL("12069", 0xC),
		/**
		 * P3 XR SetCode.
		 */	
		ADC_OFFSET_P3_XR("1206A", 0xC),
		/**
		 * P3 YR SetCode.
		 */	
		ADC_OFFSET_P3_YR("1206B", 0xC);
		
		/**
		 * SetCode name.
		 */
		private String m_sName;
		
		/**
		 * SetCode margin.
		 */
		private long m_lMargin;

		/**
		 * ADC Offset SetCodes.
		 * 
		 * @param sName SetCode name
		 * @param lMargin SetCode margin
		 */
		ADCOffsetSetCode(final String sName, final long lMargin) {
			m_sName = sName;
			m_lMargin = lMargin;
		}

		/**
		 * Retrieve SetCode name.
		 *
		 * @return SetCode name
		 */
		public String getName() {
			return m_sName;
		}

		/**
		 * Retrieve SetCode margin.
		 *
		 * @return SetCode margin
		 */
		public long getMargin() {
			return m_lMargin;
		}
	};

	/**
	 * ARC Comp Setcode.
	 */
	public enum ARCCompSetCode {	
		/**
		 * P1 Arc comp SetCode.
		 */
		ADC_OFFSET_P1_ARC_COMP("24E00", 0x5),
		/**
		 * P2P1 Arc comp SetCode.
		 */
		SUB_OFFSET_P2P1_ARC_COMP("24E01", 0x5),
		/**
		 * P2 Arc comp SetCode.
		 */
		ADC_OFFSET_P2_ARC_COMP("24E02", 0x5),
		/**
		 * P2P3 Arc comp SetCode.
		 */
		SUB_OFFSET_P2P3_ARC_COMP("24E03", 0x5),
		/**
		 * P3 Arc comp SetCode.
		 */
		ADC_OFFSET_P3_ARC_COMP("24E04", 0x5);
		
		/**
		 * SetCode name.
		 */
		private String m_sName;
		
		/**
		 * SetCode margin.
		 */
		private long m_lMargin;

		/**
		 * ARC Comp Setcodes.
		 * 
		 * @param sName SetCode name
		 * @param lMargin SetCode margin
		 */
		ARCCompSetCode(final String sName, final long lMargin) {
			m_sName = sName;
			m_lMargin = lMargin;
		}

		/**
		 * Retrieve SetCode name.
		 *
		 * @return SetCode name
		 */
		public String getName() {
			return m_sName;
		}

		/**
		 * Retrieve SetCode margin.
		 *
		 * @return SetCode margin
		 */
		public long getMargin() {
			return m_lMargin;
		}
	}
	

	/**
	 * ARC Comp Setcode.
	 */
	public enum FDCOffsetSetCode {
		/**
		 * P1 XL SetCode.
		 */
		FDC_OFFSET_P1_XL("12300", 0xC),
		/**
		 * P1 YL SetCode.
		 */
		FDC_OFFSET_P1_YL("12301", 0xC),
		/**
		 * P1 XR SetCode.
		 */
		FDC_OFFSET_P1_XR("12302", 0xC),
		/**
		 * P1 YR SetCode.
		 */
		FDC_OFFSET_P1_YR("12303", 0xC),
		/**
		 * P2 XL SetCode.
		 */
		FDC_OFFSET_P2_XL("12304", 0xC),
		/**
		 * P2 YL SetCode.
		 */
		FDC_OFFSET_P2_YL("12305", 0xC),
		/**
		 * P2 XR SetCode.
		 */
		FDC_OFFSET_P2_XR("12306", 0xC),
		/**
		 * P2 YR SetCode.
		 */
		FDC_OFFSET_P2_YR("12307", 0xC),
		/**
		 * P3 XL SetCode.
		 */
		FDC_OFFSET_P3_XL("12308", 0xC),
		/**
		 * P3 YL SetCode.
		 */
		FDC_OFFSET_P3_YL("12309", 0xC),
		/**
		 * P3 XR SetCode.
		 */
		FDC_OFFSET_P3_XR("1230A", 0xC),
		/**
		 * P3 YR SetCode.
		 */
		FDC_OFFSET_P3_YR("1230B", 0xC);
		
		/**
		 * Setcode name.
		 */
		private String m_sName;

		/**
		 * Setcode margin.
		 */
		private long m_lMargin;

		/**
		 * FDC Offset Setcodes.
		 * 
		 * @param sName setcode
		 * @param lMargin margin
		 */
		FDCOffsetSetCode(final String sName, final long lMargin) {
			m_sName = sName;
			m_lMargin = lMargin;
		}

		/**
		 * Retrieve SetCode name.
		 *
		 * @return SetCode name
		 */
		public String getName() {
			return m_sName;
		}

		/**
		 * Retrieve SetCode margin.
		 *
		 * @return SetCode margin
		 */
		public long getMargin() {
			return m_lMargin;
		}
	}

	/**
	 * �ݒ�f�[�^�R�[�h�B
	 */
	public enum BarmirrorMagBaseSetCode {
		/**
		 * XY.
		 */
		XY(null, 0),
		/**
		 * OAS FL1S FL2 SetCode.
		 */
		OAS_FL1S_FL2("13C30", 0x20),
		/**
		 * OAS FL1S FL1 SetCode.
		 */
		OAS_FL1S_FL1("13C31", 0x20),
		/**
		 * OAS FL1S FC SetCode.
		 */
		OAS_FL1S_FC("13C32", 0x20),
		/**
		 * OAS FR1 FC SetCode.
		 */
		OAS_FR1_FC("13C33", 0x20),
		/**
		 * OAS FR1 R1 SetCode.
		 */
		OAS_FR1_FR1("13C34", 0x20),
		/**
		 * OAS FR1 R2 SetCode.
		 */
		OAS_FR1_R2("13C35", 0x20);

		/** �ݒ�f�[�^�R�[�h. */
		private final String m_sName;
		/** �}�[�W��. */
		private final long m_lMargin;

		/**
		 * �R���X�g���N�^�B
		 *
		 * @param sName �ݒ�f�[�^�R�[�h
		 * @param lMargin SetCode margin
		 */
		BarmirrorMagBaseSetCode(final String sName, final long lMargin) {
			m_sName = sName;
			m_lMargin = lMargin;
		}

		/**
		 * ����(�ݒ�f�[�^�R�[�h)�̎擾�B
		 *
		 * @return ����(�ݒ�f�[�^�R�[�h)
		 */
		public String getName() {
			return m_sName;
		}

		/**
		 * �}�[�W�����擾�B
		 *
		 * @return �}�[�W��
		 */
		public long getMargin() {
			return m_lMargin;
		}
	}

	/**
	 * �ݒ�f�[�^�R�[�h�B
	 */
	public enum OASBasePlateTVAACenterPosSetCode {
		/**
		 * FL2 X SetCode.
		 */
		FL2_X("12C00"),
		/**
		 * FL2 Y SetCode.
		 */
		FL2_Y("12C01"),
		/**
		 * FL1S X SetCode.
		 */
		FL1S_X("12C02"),
		/**
		 * FL1S Y SetCode.
		 */
		FL1S_Y("12C03"),
		/**
		 * FL1 X SetCode.
		 */
		FL1_X("12C04"),
		/**
		 * FL1 Y SetCode.
		 */
		FL1_Y("12C05"),
		/**
		 * FCS X SetCode.
		 */
		FCS_X("12C06"),
		/**
		 * FCS Y SetCode.
		 */
		FCS_Y("12C07"),
		/**
		 * FC X SetCode.
		 */
		FC_X("12C08"),
		/**
		 * FC Y SetCode.
		 */
		FC_Y("12C09"),
		/**
		 * FR1S X SetCode.
		 */
		FR1S_X("12C0A"),
		/**
		 * FR1S Y SetCode.
		 */
		FR1S_Y("12C0B"),
		/**
		 * FR1 X SetCode.
		 */
		FR1_X("12C0C"),
		/**
		 * FR1 Y SetCode.
		 */
		FR1_Y("12C0D"),
		/**
		 * FR2 X SetCode.
		 */
		FR2_X("12C0E"),
		/**
		 * FR2 Y SetCode.
		 */
		FR2_Y("12C0F");

		/** �ݒ�f�[�^�R�[�h. */
		private final String m_sName;

		/**
		 * �R���X�g���N�^�B
		 *
		 * @param sName �ݒ�f�[�^�R�[�h
		 */
		OASBasePlateTVAACenterPosSetCode(final String sName) {
			m_sName = sName;
		}

		/**
		 * ����(�ݒ�f�[�^�R�[�h)�̎擾�B
		 *
		 * @return ����(�ݒ�f�[�^�R�[�h)
		 */
		public String getName() {
			return m_sName;
		}

		/**
		 * �}�[�W�����擾�B
		 *
		 * @return �}�[�W��
		 */
		public long getMargin() {
			return 0x01;
		}
	}
	
	/**
	 * �ݒ�f�[�^�R�[�h�B
	 */
	public enum LineSetCode {
		/** Line. */
		LINE(null, 0),

		/** Position Offset WHT. */
		POS_OFF_WHT("2D100", 0x10),
		/** Position Offset Y. */
		POS_OFF_Y("2D101", 0x10),
		/** Position Offset Z. */
		POS_OFF_Z("2D102", 0x10),
		/** Position Offset T. */
		POS_OFF_T("2D103", 0x10),

		/** Measurement FL2 WHT. */
		MEAS_FL2_WHT("1D100", 0x10),
		/** Measurement FL2 Y. */
		MEAS_FL2_Y("1D101", 0x10),
		/** Measurement FL1s WHT. */
		MEAS_FL1s_WHT("1D102", 0x10),
		/** Measurement FL1s Y. */
		MEAS_FL1s_Y("1D103", 0x10),
		/** Measurement FL1 WHT. */
		MEAS_FL1_WHT("1D104", 0x10),
		/** Measurement FL1 Y. */
		MEAS_FL1_Y("1D105", 0x10),
		/** Measurement FCs WHT. */
		MEAS_FCs_WHT("1D106", 0x10),
		/** Measurement FCs Y. */
		MEAS_FCs_Y("1D107", 0x10),
		/** Measurement FC WHT. */
		MEAS_FC_WHT("1D108", 0x10),
		/** Measurement FC Y. */
		MEAS_FC_Y("1D109", 0x10),
		/** Measurement FR1s WHT. */
		MEAS_FR1s_WHT("1D10A", 0x10),
		/** Measurement FR1s Y. */
		MEAS_FR1s_Y("1D10B", 0x10),
		/** Measurement FR1 WHT. */
		MEAS_FR1_WHT("1D10C", 0x10),
		/** Measurement FR1 Y. */
		MEAS_FR1_Y("1D10D", 0x10),
		/** Measurement FR2 WHT. */
		MEAS_FR2_WHT("1D10E", 0x10),
		/** Measurement FR2 Y. */
		MEAS_FR2_Y("1D10F", 0x10),

		/** Light Control FL2 WHT. */
		LIGHT_FL2_WHT("39100", 0x10),
		/** Light Control FL2 Y. */
		LIGHT_FL2_RED("39108", 0x10),
		/** Light Control FL1s WHT. */
		LIGHT_FL1s_WHT("39101", 0x10),
		/** Light Control FL1s Y. */
		LIGHT_FL1s_RED("39109", 0x10),
		/** Light Control FL1 WHT. */
		LIGHT_FL1_WHT("39102", 0x10),
		/** Light Control FL1 Y. */
		LIGHT_FL1_RED("3910A", 0x10),
		/** Light Control FCs WHT. */
		LIGHT_FCs_WHT("39103", 0x10),
		/** Light Control FCs Y. */
		LIGHT_FCs_RED("3910B", 0x10),
		/** Light Control FC WHT. */
		LIGHT_FC_WHT("39104", 0x10),
		/** Light Control FC Y. */
		LIGHT_FC_RED("3910C", 0x10),
		/** Light Control FR1s WHT. */
		LIGHT_FR1s_WHT("39105", 0x10),
		/** Light Control FR1s Y. */
		LIGHT_FR1s_RED("3910D", 0x10),
		/** Light Control FR1 WHT. */
		LIGHT_FR1_WHT("39106", 0x10),
		/** Light Control FR1 Y. */
		LIGHT_FR1_RED("3910E", 0x10),
		/** Light Control FR2 WHT. */
		LIGHT_FR2_WHT("39107", 0x10),
		/** Light Control FR2 Y. */
		LIGHT_FR2_RED("3910F", 0x10),

		/** Filter Setting FL2. */
		FILTER_FL2("13808", 0x8),
		/** Filter Setting FL1s. */
		FILTER_FL1s("13809", 0x8),
		/** Filter Setting FL1. */
		FILTER_FL1("1380A", 0x8),
		/** Filter Setting FCs. */
		FILTER_FCs("1380B", 0x8),
		/** Filter Setting FC. */
		FILTER_FC("1380C", 0x8),
		/** Filter Setting FR1s. */
		FILTER_FR1s("1380D", 0x8),
		/** Filter Setting FR1. */
		FILTER_FR1("1380E", 0x8),
		/** Filter Setting FR2. */
		FILTER_FR2("1380F", 0x8);

		/** �ݒ�f�[�^�R�[�h. */
		private final String m_sName;
		/** �}�[�W��. */
		private final long m_lMargin;

		/**
		 * �R���X�g���N�^�B
		 *
		 * @param sName �ݒ�f�[�^�R�[�h
		 * @param lMargin �}�[�W��
		 */
		LineSetCode(final String sName, final long lMargin) {
			m_sName = sName;
			m_lMargin = lMargin;
		}

		/**
		 * ����(�ݒ�f�[�^�R�[�h)�̎擾�B
		 *
		 * @return ����(�ݒ�f�[�^�R�[�h)
		 */
		public String getName() {
			return m_sName;
		}

		/**
		 * �}�[�W�����擾�B
		 *
		 * @return �}�[�W��
		 */
		public long getMargin() {
			return m_lMargin;
		}
	}

	/**
	 * ProcessDataRecipeValidator constructor.
	 */
	public ProcessDataRecipeValidator() {
		initialize();
	}
	
	/**
	 * ProcessDataRecipeValidator constructor.
	 * 
	 * @param isMultiCommonProcess Multi common process
	 */
	public ProcessDataRecipeValidator(final boolean isMultiCommonProcess) {
		m_IsMultiCommonProcess = isMultiCommonProcess;
		initialize();
	}
	
	/**
	 * Initialize ProcessDataRecipeValidator.
	 */
	private void initialize() {
		m_ConsistencyCheck = new ConsistencyCheckForProcess(m_IsMultiCommonProcess);
		setConsistencyCheck(m_ConsistencyCheck);
	}

	/**
	 * Performs out of range checking for ProcessData.
	 * 
	 * @return ProcessData error
	 */
	private Map<String, List<String>> performValueRangeCheck() {
		final Map<String, List<String>> mProcessDataRangeError = new HashMap<String, List<String>>();
		for (final Entry<String, AbstractConsoleData> entry : m_mapConsDataForProcess.entrySet()) {
			final AbstractConsoleData consData = entry.getValue();

			if (consData.isOutOfRange()) {
				mProcessDataRangeError.put(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE, Arrays.asList(entry.getKey()));
				break;
			}
		}

		return mProcessDataRangeError;
	}

	/**
	 * Performs calc job for ProcessData.
	 * 
	 * @param sDeviceName Device name
	 * @param sProcessName Process name
	 * @param mapProcess Mapping of setcode and value for ProcessData
	 * @param mapDevice Mapping of setcode and value for DeviceData
	 * @return Mapping of calculated Setcode and value
	 */
	public Map<String, AbstractConsoleData> performCalcJobForProcess(
			final String sDeviceName, 
			final String sProcessName,
			final Map<String, AbstractConsoleData> mapProcess,
			final Map<String, AbstractConsoleData> mapDevice) {
		m_JobCalculationManagerAccessService =
				NameService.getConsoleServiceFactory().getJobCalculationManagerAccessService();
		return m_JobCalculationManagerAccessService.
				calcJobForProcess(sDeviceName, sProcessName, mapProcess, mapDevice);
	}

	/**
	 * Performs check value wrong for ProcessData.
	 * 
	 * @param iExposureMode Exposure Mode
	 * @param bEnabledXSMB Check if XSMB checker is enabled
	 * @param bEnabledYSMB Check if YSMB checker is enabled
	 * @param mapConsData Mapping of setcode and value for DeviceData
	 * @return ValueWrongCheckProxy
	 */
	public ValueWrongCheckProxy performCheckValueWrong(final long iExposureMode,
			final boolean bEnabledXSMB,
			final boolean bEnabledYSMB,
			final Map<String, AbstractConsoleData> mapConsData) {

		final ValueWrongCheckProxy checkProxy = new ValueWrongCheckProxy(RecipeConst.VALUE_CHECK_OK);

		// FreeLayout�ȊO�̓`�F�b�N���ڂȂ�
		if (JobEditConst.EXPO_MODE_FREE != iExposureMode) {
			return checkProxy;
		}
		
		// SMB�@�\�̗����������̏ꍇ�̓`�F�b�N�ΏۊO
		if (!bEnabledYSMB && !bEnabledXSMB) {
			return checkProxy;
		}
		
		// �f�o�C�X��SMB�f�[�^�s���`�F�b�N
		final Map<String, ConsBase> mapConvertedMap = convertAbstractConsoleDataToConsBase(mapConsData);
		m_valueWrongCheck = new ValueWrongCheck();
		return m_valueWrongCheck.checkSMBDataValueForProcess(mapConvertedMap, true);
	}

	private Map<String, ConsBase> convertAbstractConsoleDataToConsBase(final Map<String, AbstractConsoleData> mapConsData) {
		final Map<String, ConsBase> mapData = new HashMap<String, ConsBase>();

		for (final Entry<String, AbstractConsoleData> entryConsData : mapConsData.entrySet()) {
			final ConsBase consBase = ConsoleDataUtils.setDataToConsData(entryConsData.getValue());

			if (null != consBase) {
				mapData.put(consBase.getName(), consBase);
			}
		}
		return mapData;
	}

	/**
	 * Validates ProcessData Recipe.
	 * 
	 * @param mapConsDataForProcess Mapping of setcode and value for process data
	 * @param mapConsDataForDevice Mapping of setcode and value for device data
	 * @param sDeviceName Device name
	 * @param sProcessName Process name
	 * @return ProcessData error
	 */
	public Map<String, List<String>> validateProcessDataRecipe(final Map<String, AbstractConsoleData> mapConsDataForProcess,
			final Map<String, AbstractConsoleData> mapConsDataForDevice, final String sDeviceName,
			final String sProcessName) {
		Map<String, List<String>> mapProcessDataError = new HashMap<String, List<String>>();
		m_mapConsDataForProcess = mapConsDataForProcess;
		m_mapConsDataForDevice = mapConsDataForDevice;
		m_sDeviceName = sDeviceName;
		m_sProcessName = sProcessName;

		mapProcessDataError = checkDuplicateSetCode();
		if (mapProcessDataError.size() == 0) {

			// Prepare data for validation
			mapProcessDataError.putAll(prepareDataForValidation());
			if (mapProcessDataError.size() != 0) {
				return mapProcessDataError;
			}

			// Perform consistency check
			m_ConsistencyCheck.checkConsistency(ConsistencyCheckIF.IDX_ALL, m_mapConsDataForProcess);
			mapProcessDataError.putAll(((ConsistencyCheckForProcess) m_ConsistencyCheck).getErrorSetCodeMap());
			if (mapProcessDataError.size() != 0) {
				return mapProcessDataError;
			}

			// Perform value range check
			mapProcessDataError.putAll(performValueRangeCheck());
			if (mapProcessDataError.size() != 0) {
				return mapProcessDataError;
			}

			// Perform calcJob
			final Map<String, AbstractConsoleData> mapCalcData =
					performCalcJobForProcess(sDeviceName, sProcessName,
							m_mapConsDataForProcess, m_mapConsDataForDevice);

			// Perform check proxy
			final Map<String, AbstractConsoleData> mapCheckData = new HashMap<String, AbstractConsoleData>();
			mapCheckData.putAll(m_mapConsDataForDevice);
			mapCheckData.putAll(m_mapConsDataForProcess);
			
			replaceAllConsData(mapCalcData, mapCheckData);

			ValueWrongCheckProxy checkProxy = null;
			if (!checkMxCompModeChange()) {
				checkProxy = new ValueWrongCheckProxy(RecipeConst.VALUE_ERROR_MX_COMP_CHANGE,
						m_sErrorOffsetZeroSetCode);
			} else {
				m_FunctionChecker = NameService.getConsoleServiceFactory().getFunctionCheckerService();
				checkProxy =
						performCheckValueWrong((int) mapCheckData.get(JobEditConst.EXPO_MODE_SETCODE).getRealValue(), 
						m_FunctionChecker.isFunctionEnabled(XSlitMaskingBladeChecker.class.getCanonicalName()),
						m_FunctionChecker.isFunctionEnabled(SlitMaskingBladeChecker.class.getCanonicalName()),
						mapCheckData);
			}
			final String sErrorMessage = getDataCheckErrorMessage(checkProxy);
			final List<String> listErrorSetcodes = checkProxy.getErrorSetCodeList();
			mapProcessDataError.put(sErrorMessage, listErrorSetcodes);
			if (mapProcessDataError.size() != 0) {
				return mapProcessDataError;
			}

			// Adjust Plate AFC related data after save
			adjustPlateAfcTab();
		}

		return mapProcessDataError;
	}

	/**
	 * Performs checking if Mx Comp Mode is changed.
	 * 
	 * @return true if changed, otherwise false
	 */
	private boolean checkMxCompModeChange() {
		// MX Compensation Mode��ConsoleData���擾
		final ConsoleDataLong consMxCompMode = getConsLong(RecipeConst.SETCODE_MX_COMP_MODE);

		// ���ݒl���o�b�N�A�b�v�l�ȏ�ł���ꍇ�̓`�F�b�NOK(���ύX�����܂�)
		// ���`�F�b�N�ΏۂƂȂ�̂́A�������l�֕ύX���ꂽ�ꍇ�̂�
		final long lValue = consMxCompMode.getValue();
		final long lBackupValue = consMxCompMode.getBackupValue();
		if (lBackupValue <= lValue) {
			return true;
		}

		// Offset�[������
		final List<String> listOffsetZeroSetCode = getOffsetZeroSetCode(getStepNum());
		for (final String sOffsetZeroSetCode : listOffsetZeroSetCode) {
			final AbstractConsoleData consOffsetData = getProcessConsData(sOffsetZeroSetCode);
			if (null == consOffsetData) {
				ConsoleLogger.getLogger().warning("[ProcessDataRecipeValidator:checkMxCompModeChange()] "
						+ "Offset Zero SetCode is Illegal.[" + sOffsetZeroSetCode + "]");
				continue;
			}

			// �[���ȊO�̒l�����݂������_�Ń`�F�b�NNG
			if (0 != consOffsetData.getRealValue()) {
				m_sErrorOffsetZeroSetCode.add(sOffsetZeroSetCode);
				return false;
			}
		}

		// �`�F�b�NOK
		return true;
	}

	/**
	 * Creates Offset Zero Setcode list.
	 * 
	 * @param iStepNum Step Number
	 * @return SetCode list
	 */
	private List<String> getOffsetZeroSetCode(final int iStepNum) {
		final List<String> listOffsetZeroSetCode = new ArrayList<String>();
		final int iMaxStepNum = 36;

		// ADC AA Offset
		for (final ADCOffsetSetCode adcOffsetSetCode : ADCOffsetSetCode.values()) {
			listOffsetZeroSetCode.addAll(createColumnSetCodeList(adcOffsetSetCode.getName(),
					adcOffsetSetCode.getMargin(),
					iMaxStepNum).subList(0, iStepNum));
		}

		// ARC Comp
		for (final ARCCompSetCode arcCompSetCode : ARCCompSetCode.values()) {
			listOffsetZeroSetCode.addAll(createColumnSetCodeList(arcCompSetCode.getName(),
					arcCompSetCode.getMargin(),
					iMaxStepNum).subList(0, iStepNum));
		}

		// FDC AA Offset
		for (final FDCOffsetSetCode fdcOffsetSetCode : FDCOffsetSetCode.values()) {
			listOffsetZeroSetCode.addAll(createColumnSetCodeList(fdcOffsetSetCode.getName(),
					fdcOffsetSetCode.getMargin(),
					iMaxStepNum).subList(0, iStepNum));
		}

		return listOffsetZeroSetCode;
	}
	
	/**
	 * Confirm if OAS job is executable or not.
	 * 
	 * @param mapDevice Mapping of setcode and value for device data
	 * @param mapProcess Mapping of setcode and value for process data
	 * @param sDeviceName Device name
	 * @param sProcessName Process name
	 * @return Error Message
	 */
	private String checkOASJobExecute(final Map<String, AbstractConsoleData> mapDevice,
			final Map<String, AbstractConsoleData> mapProcess, final String sDeviceName, final String sProcessName) {
		return NameService.getConsoleServiceFactory().getJobCalculationManagerAccessService().
				checkOASJobExecute(sDeviceName, sProcessName, mapDevice, mapProcess);
	}

	/**
	 * Checks the consistency of the OAS Base Line Measurement Setting.
	 * 
	 * @param sDeviceName Device name
	 * @param sProcessName Process name
	 * @param mapConsDataDevice Mapping of setcode and value for device data
	 * @param mapCloneConsDataProcess Cloned mapping of setcode and value for process data
	 * @return Error Message
	 */
	private String checkOASBaseLineMeasurementShot(final String sDeviceName, final String sProcessName,
			final Map<String, AbstractConsoleData> mapConsDataDevice,
			final Map<String, AbstractConsoleData> mapCloneConsDataProcess) {
		return NameService.getConsoleServiceFactory().getJobCalculationManagerAccessService().
				checkOASBaseLineMeasurementShot(sDeviceName, sProcessName, mapConsDataDevice, mapCloneConsDataProcess);
	}

	/**
	 * OAS Line�^�uOAS Measurement Setting���ύX����Ă��邩�ǂ����B
	 *
	 * @param mapConsDataProcess Mapping of setcode and data for ProcessData
	 * @return true:�ύX���� false:�ύX�Ȃ�
	 */
	public boolean isChangeOASMeasurementSetting(final Map<String, AbstractConsoleData> mapConsDataProcess) {
		for (int iRowIndex = 0; iRowIndex < MeasurementSettingData.ROWS; iRowIndex++) {
			// Use OAS�ȊO�̍��ڂ̃`�F�b�N
			for (final LineSettingSetCode code : LineSettingSetCode.values()) {
				if (LineSettingSetCode.ALIGN_POS_FDC.equals(code)) {
					continue;
				}
				// �ݒ�f�[�^�R�[�h���������X�g�ǉ�
				final String sSetcode =
						MeasurementSettingData.makeSetCode(iRowIndex, code.getName(), code.getMargin());
				if (null != sSetcode && !sSetcode.isEmpty()
						&& !mapConsDataProcess.get(sSetcode).isSameData(null)) {
					return true;
				}
			}
			// Use OAS�̃`�F�b�N
			final String sUseOASSetCode =
					MeasurementSettingData.makeSetCode(
							iRowIndex, MeasurementSettingData.OAS_USE_SETCODE, MeasurementSettingData.OAS_USE_MARGIN);
			if (null != sUseOASSetCode && !sUseOASSetCode.isEmpty()
					&& !mapConsDataProcess.get(sUseOASSetCode).isSameData(null)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Force values for Change Measurement Parameter.
	 */
	private void forceChangeMeasurementParameter() {
		m_FunctionChecker = NameService.getConsoleServiceFactory().getFunctionCheckerService();
		final boolean bOASRedLED = m_FunctionChecker.isFunctionEnabled(OASLEDRedChecker.class.getCanonicalName())
				|| m_FunctionChecker.isFunctionEnabled(OASLEDRedE813Checker.class.getCanonicalName());
		
		// 1�񂸂ݒ�f�[�^�R�[�h��ݒ�
		for (final LineSetCode code : LineSetCode.values()) {

			// �ԐFLED�������Ȃ�΁A�Ώۂ̐ݒ�f�[�^���Ƃ΂��B
			if (!bOASRedLED && LineSetCode.LIGHT_FL2_RED.equals(code)
					|| !bOASRedLED && LineSetCode.LIGHT_FL1s_RED.equals(code)
					|| !bOASRedLED && LineSetCode.LIGHT_FL1_RED.equals(code)
					|| !bOASRedLED && LineSetCode.LIGHT_FCs_RED.equals(code)
					|| !bOASRedLED && LineSetCode.LIGHT_FC_RED.equals(code)
					|| !bOASRedLED && LineSetCode.LIGHT_FR1s_RED.equals(code)
					|| !bOASRedLED && LineSetCode.LIGHT_FR1_RED.equals(code)
					|| !bOASRedLED && LineSetCode.LIGHT_FR2_RED.equals(code)) {
				continue;
			}

			for (int iRowIndex = 0; iRowIndex < RecipeConst.LINE_MAX; iRowIndex++) {
				// �ݒ�f�[�^�R�[�h����
				final String sSetcode = makeSetCode(iRowIndex, code.getName(), code.getMargin());

				if (null != sSetcode && !sSetcode.isEmpty()) {
					// �R���\�[���f�[�^�̎擾
					final AbstractConsoleData consData = getProcessConsData(sSetcode);
					// �f�t�H���g�l�łȂ���΃f�t�H���g�l���Z�b�g����
					if (consData instanceof ConsoleDataLong) {
						final ConsoleDataLong consLong = (ConsoleDataLong) consData;
						final long lValue = consLong.getValue();
						final long lDefault = consLong.getValueDefault();
						if (lDefault != lValue) {
							consLong.setValue(lDefault);
						}
					} else if (consData instanceof ConsoleDataDouble) {
						final ConsoleDataDouble consDouble = (ConsoleDataDouble) consData;
						final double dValue = consDouble.getValue();
						final double dDefault = consDouble.getValueDefault();
						if (0 != Double.compare(dDefault, dValue)) {
							consDouble.setValue(dDefault);
						}
					}
				}
			}
		}
	}
	
	/**
	 * OASZeroLayerMarkAlignment ���L�����ǂ����𔻒肷��B
	 *
	 * @return ZeroLayerMarkAlignment�܂���AMF�v�����s���ꍇ�͏ꍇ��true�A���ɍs��Ȃ��ꍇ��false
	 */
	private boolean isOASZeroLayerMarkAlignmentOrAmfMeas() {
		m_FunctionChecker = NameService.getConsoleServiceFactory().getFunctionCheckerService();
		final boolean bOASZeroLayer =
				m_FunctionChecker.isFunctionEnabled(OASZeroLayerChecker.class.getCanonicalName());
		final int iBoxMarkAlignment = (int) getProcessConsData(JobEditConst.OAS_ZERO_LAYER_ALIGNMENT).getRealValue();
		final boolean bZeroLayerOn = iBoxMarkAlignment == 1;
		
		return bOASZeroLayer && bZeroLayerOn;
	}

	/**
	 * OAS Zero Layer Tab�̃p�����[�^�G���[�`�F�b�N�����{����.
	 *
	 * @return �G���[�̏ꍇ�F�G���[���b�Z�[�W�A�G���[�łȂ��ꍇ�F��
	 */
	private Map<String, List<String>> checkOASZeroLayerTabParameterError() {
		final Map<String, List<String>> mapDataError = new HashMap<String, List<String>>();
		final String sErrorMessage = "<html>[ZeroLayer/AMF]<br>"
										+ "Calibration Schedule Parameters<br>"
										+ "Set 'ON' at least one.</html>";

		final int iOFF = 0;
		final boolean bLotCountOFF =
				iOFF == getProcessConsData(JobEditConst.OAS_ZERO_LAYER_CALIB_SCHE_LOT_COUNT).getRealValue();
		final boolean bPlateIntervalOFF =
				iOFF == getProcessConsData(JobEditConst.OAS_ZERO_LAYER_CALIB_SCHE_PLATE_INTERVAL).getRealValue();
		final boolean bLastTimeOFF =
				iOFF == getProcessConsData(JobEditConst.OAS_ZERO_LAYER_CALIB_SCHE_LASTTIME).getRealValue();
		if (bLotCountOFF && bPlateIntervalOFF && bLastTimeOFF) {
			if (bLotCountOFF) {
				mapDataError.put(sErrorMessage, Arrays.asList(JobEditConst.OAS_ZERO_LAYER_CALIB_SCHE_LOT_COUNT));
			} else if (bPlateIntervalOFF) {
				mapDataError.put(sErrorMessage, Arrays.asList(JobEditConst.OAS_ZERO_LAYER_CALIB_SCHE_PLATE_INTERVAL));
			} else if (bLastTimeOFF) {
				mapDataError.put(sErrorMessage, Arrays.asList(JobEditConst.OAS_ZERO_LAYER_CALIB_SCHE_LASTTIME));
			}
			return mapDataError;
		} else {
			return mapDataError;
		}
	}

	/**
	 * Checks if the OAS Layout has been changed or not.
	 * 
	 * @param mapConsDataProcess Mapping of SetCode and Value for Process data
	 * @return true if changed, otherwise false
	 */
	public boolean isChangeOASLayout(final Map<String, AbstractConsoleData> mapConsDataProcess) {
		// �ePos���ƂɕύX����Ă��邩�ǂ����`�F�b�N����
		for (final OASLayoutSetCode pos : OASLayoutSetCode.values()) {
			final String sSetcode = pos.getName();
			// �ꂩ���ł��ύX����Ă����true:
			if (!mapConsDataProcess.get(sSetcode).isSameData(null)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * OAS/Z Sensor Offset Measurement�������I�Ƀf�t�H���g�ɕύX����B
	 */
	private void forceChangeOASZSensorOffsetMeasurement() {

		// Meas Exec.���f�t�H���g�łȂ���ΕύX����
		final ConsoleDataLong consMeasExec = getConsLong(OasTabConst.MEAS_EXEC_SETCODE);
		final long lDefault = consMeasExec.getValueDefault();
		if (lDefault != consMeasExec.getRealValue()) {
			consMeasExec.setRealValue(lDefault);
    	}

		// OAS Home Sensor���f�t�H���g�łȂ���ΕύX����
		final ConsoleDataDouble consHomeSensor =
				getConsDouble(OasTabConst.SetCode.OAS_TAB_HOME_SENSOR_OFFSET_NAME.getSetCode());
		final double dDefault = consHomeSensor.getValueDefault();
		if (Double.compare(dDefault, consHomeSensor.getRealValue()) != 0) {
			consHomeSensor.setValue(dDefault);
		}
		return;
	}

	/**
	 * Barmirror Magnification Base�������I�Ƀf�t�H���g�ɕύX����B
	 */
	private void forceChangeBarmirrorMagnificationBase() {
		final int iBarMirrorMagBaseTableRows = 2;

		for (final BarmirrorMagBaseSetCode glassPos : BarmirrorMagBaseSetCode.values()) {
			for (int iRowIndex = 0; iRowIndex < iBarMirrorMagBaseTableRows; iRowIndex++) {
				final String sSetcode = makeSetCode(iRowIndex, glassPos.getName(), glassPos.getMargin());

				if (null != sSetcode && !sSetcode.isEmpty()) {
					// �R���\�[���f�[�^�̎擾
					final AbstractConsoleData consData = getProcessConsData(sSetcode);
					// �f�t�H���g�l�łȂ���΃f�t�H���g�l���Z�b�g����
					if (consData instanceof ConsoleDataLong) {
						final ConsoleDataLong consLong = (ConsoleDataLong) consData;
						final long lValue = consLong.getValue();
						final long lDefault = consLong.getValueDefault();
						if (lDefault != lValue) {
							consLong.setValue(lDefault);
						}
					} else if (consData instanceof ConsoleDataDouble) {
						final ConsoleDataDouble consDouble = (ConsoleDataDouble) consData;
						final double dValue = consDouble.getValue();
						final double dDefault = consDouble.getValueDefault();
						if (0 != Double.compare(dDefault, dValue)) {
							consDouble.setValue(dDefault);
						}
					}
				}
			}
		}
		return;
	}
	
	/**
	 * OAS Base Plate TVAA Center Position�������I�Ƀf�t�H���g�ɕύX����B
	 */
	private void forceChangeOASBasePlateTVAACenterPosition() {
		for (final OASBasePlateTVAACenterPosSetCode pos : OASBasePlateTVAACenterPosSetCode.values()) {
			final long lValue = m_mapConsDataForProcess.get(pos.getName()).getRealValue();

			final ConsoleDataLong consData = getConsLong(pos.getName());
			final long lDefault = consData.getValueDefault();

			if (lDefault != lValue) {
				consData.setRealValue(lDefault);
			}
		}
		return;
	}

	/**
	 * Performs data adjustments for OAS layout.
	 */
	private void forceChangeForOASLayout() {
		if (isOASParanemic()) {
			// OAS/Z Sensor Offset Measurement��Default�ɂ���
			forceChangeOASZSensorOffsetMeasurement();
			// Barmirror Magnification Base��Default�ɂ���
			forceChangeBarmirrorMagnificationBase();
			// OAS Base Plate TVAA Center ��Default�ɂ���
			forceChangeOASBasePlateTVAACenterPosition();
		}
	}

	/**
	 * Checks if OAS Paranemic is enabled.
	 * @return true if enabled, otherwise false.
	 */
	private boolean isOASParanemic() {
		m_FunctionChecker = NameService.getConsoleServiceFactory().getFunctionCheckerService();
		final boolean bOASUnitTypeParanemic =
				m_FunctionChecker.isFunctionEnabled(OASUnitTypeParanemicChecker.class.getCanonicalName());
		final boolean bMachineTypeH800 =
				m_FunctionChecker.isFunctionEnabled(H800Checker.class.getCanonicalName());
		//final boolean bMachineTypeH800 =
		//      m_FunctionChecker.isFunctionEnabled(MachineTypeH800Checker.class.getCanonicalName());

		return bOASUnitTypeParanemic || bMachineTypeH800;
	}
	/**
	 * Long�^�R���\�[���f�[�^�̎擾�B
	 *
	 * @param setcode �ݒ�f�[�^
	 * @return Long�R���\�[���f�[�^
	 */
	private ConsoleDataLong getConsLong(final String setcode) {
		final AbstractConsoleData consData = m_mapConsDataForProcess.get(setcode);
		if (consData instanceof ConsoleDataLong) {
			return (ConsoleDataLong) consData;
		} else {
			ConsoleLogger.getLogger().
				warning("[ProcessDataRecipeValidator:getConsLong()] (" + setcode + ") Cast Error!");
			return null;
		}
	}

	/**
	 * Double�^�R���\�[���f�[�^�̎擾�B
	 *
	 * @param setcode �ݒ�f�[�^
	 * @return Double�R���\�[���f�[�^
	 */
	private ConsoleDataDouble getConsDouble(final String setcode) {
		final AbstractConsoleData consData = m_mapConsDataForProcess.get(setcode);
		if (consData instanceof ConsoleDataDouble) {
			return (ConsoleDataDouble) consData;
		} else {
			ConsoleLogger.getLogger().
				warning("[ProcessDataRecipeValidator:getConsDouble()] (" + setcode + ") Cast Error!");
			return null;
		}
	}

	/**
	 * Gets data from ProcessData map.
	 * 
	 * @param setcode Setcode name
	 * @return Corresponding data of the given setcode
	 */
	private AbstractConsoleData getProcessConsData(final String sSetCode) {
		AbstractConsoleData consData = null;
		if (m_mapConsDataForProcess.containsKey(sSetCode)) {
			consData = m_mapConsDataForProcess.get(sSetCode);
		} else {
			ConsoleLogger.getLogger().info("[getProcessConsData] m_mapConsDataForProcess does not contain: ["
					+ sSetCode + "]");
		}
		return consData;
	}
	
	/**
	 * Gets data from DeviceData map.
	 * 
	 * @param setcode Setcode name
	 * @return Corresponding data of the given setcode
	 */
	private AbstractConsoleData getDeviceConsData(final String setcode) {
		final AbstractConsoleData consData = m_mapConsDataForDevice.get(setcode);
		return consData;
	}
	
	/**
	 * Peform data adjustments.
	 * 
	 * @return mapProcessDataError
	 */
	private Map<String, List<String>> prepareDataForValidation() {
		final Map<String, List<String>> mapProcessDataError = new HashMap<String, List<String>>();
		m_FunctionChecker = NameService.getConsoleServiceFactory().getFunctionCheckerService();
		final boolean bOASUnitTypeParnemic = 
				m_FunctionChecker.isFunctionEnabled(OASUnitTypeParanemicChecker.class.getCanonicalName());
		final int iHybridMode =
				(int) m_mapConsDataForProcess.get(OasTabConst.SetCode.HYBRID_MODE.getSetCode()).getRealValue();
		final boolean bOASJobParanemic = 0 != iHybridMode && bOASUnitTypeParnemic;

		//save related data adjustments
		if (bOASJobParanemic) {
			final String sCheckResult = 
					checkOASJobExecute(m_mapConsDataForDevice, m_mapConsDataForProcess, m_sDeviceName, m_sProcessName);
			mapProcessDataError.putAll(getCalcJobErrorSetCodeMap());
			if (mapProcessDataError.size() != 0) {
				return mapProcessDataError;
			}

			final String sBaseLineCheck = 
					checkOASBaseLineMeasurementShot(m_sDeviceName, m_sProcessName, m_mapConsDataForDevice,
							m_mapConsDataForProcess);
			mapProcessDataError.putAll(getCalcJobErrorSetCodeMap());
			if (mapProcessDataError.size() != 0) {
				return mapProcessDataError;
			}

			if (isChangeOASLayout(m_mapConsDataForProcess)) {
				forceChangeForOASLayout();
			}

			if (isChangeOASMeasurementSetting(m_mapConsDataForProcess)) {
				forceChangeMeasurementParameter();
			}
		}

		if (isOASZeroLayerMarkAlignmentOrAmfMeas()) {
			mapProcessDataError.putAll(checkOASZeroLayerTabParameterError());
			if (mapProcessDataError.size() != 0) {
				return mapProcessDataError;
			}
		}

		forceValueForMaskLayoutVSCP();

		forceValueForOpti50();
		
		if (!isEdgeModeAFCFast()) {
			setForceEdgeModeAFCFastOff();
		}

		//Force value for Mask Alignment/Plate
		setConsDataValue(RecipeConst.SETCODE_PLATE_AA_PRE_LIGHT_MODE, "4");
		setConsDataValue(RecipeConst.SETCODE_PLATE_AA_FINE_LIGHT_MODE, "4");
		setConsDataValue(RecipeConst.SETCODE_MASK_ALIGN_LIGHT_MODE, "4");

		//download related data adjustments
		adjustProcessControlTab();
		adjustMaskBendParticleInspectionTab();
		adjustPlateAATab();
		adjustOASTab();
		
		return mapProcessDataError;
	}

	/**
	 * Retrieve error SetCode mapping.
	 * @return Map
	 */
	private Map<String, List<String>> getCalcJobErrorSetCodeMap() {
		return NameService.getConsoleServiceFactory().getJobCalculationManagerAccessService().getErrorSetCode();
	}

	/**
	 * Performs data adjustments for ADC Mode Opti 50.
	 * @return boolean
	 */
	private boolean forceValueForOpti50() {
		//Opti5.0�Ȃ��
		if (RecipeConst.ADCMODE_OPTI50 == getADCMode()) {
			final String sFDCAlignmentMain = "16400";
			final String sFDCAlignmentScan = "2C790";
			int counter = 0;
			for (int ii = 1; ii < getStepNum(); ii++) {
				final long lSetCodeMain = Long.parseLong(sFDCAlignmentMain, 16) + ii;
				final long lSetCodeScan = Long.parseLong(sFDCAlignmentScan, 16) + ii;

				if (getProcessConsData(CommonUtil.toHexString(lSetCodeMain, 5)).getRealValue() == 1) {
					counter++;
				}
			}

			if (counter == 0) {
				final int iExpoMode = (int) m_mapConsDataForDevice.get(JobEditConst.EXPO_MODE_SETCODE).getRealValue();
				if (RecipeConst.EXPOMODE_FREELAYOUT ==  iExpoMode) {
					final String setcodeX = "02030";
					final String setcodeY = "02031";
					final String setcodeMask = "02032";

					// ��ʂɕK�v�Ȑݒ�f�[�^���X�g���擾
					final List<String> listSetData = new ArrayList<>();
					for (int ii = 0; ii < 36; ii++) {
						listSetData.add(makeSetCode(ii, setcodeX, 3));
						listSetData.add(makeSetCode(ii, setcodeY, 3));
						listSetData.add(makeSetCode(ii, setcodeMask, 3));
					}

					// 1shot�ڂɃ}�X�N���ݒ肳��Ă��Ȃ���������I������B
					if (0 == getProcessConsData(setcodeMask).getRealValue()) {
						return false;
					}

					// 1shot�ڂ̍��W���o���Ă���
					final long shot1X = m_mapConsDataForDevice.get(setcodeX).getRealValue();
					final long shot1Y = m_mapConsDataForDevice.get(setcodeY).getRealValue();

					long maxDist = -1;
					long maxId = 0;
					for (int ii = 1; ii < 36; ii++) {
						final long dx = Math.abs(m_mapConsDataForDevice.get(makeSetCode(ii, setcodeX, 3)).
								getRealValue() - shot1X);
						final long dy = Math.abs(m_mapConsDataForDevice.get(makeSetCode(ii, setcodeY, 3)).
								getRealValue() - shot1Y);

						final long dist = dx * dx + dy * dy;
						if (dist > maxDist) {
							maxDist = dist;
							maxId = ii;
						}
					}

					final long lSetCodeMain = Long.parseLong(sFDCAlignmentMain, 16) + maxId;
					final long lSetCodeScan = Long.parseLong(sFDCAlignmentScan, 16) + maxId;
					setConsDataValue(CommonUtil.toHexString(lSetCodeMain, 5), "1");
					setConsDataValue(CommonUtil.toHexString(lSetCodeScan, 5), "1");

				} else {
					final String setcodeX = "220D0";
					final String setcodeY = "220D1";

					// ��ʂɕK�v�Ȑݒ�f�[�^���X�g���擾
					final List<String> listSetData = new ArrayList<>();
					for (int ii = 0; ii < getStepNum(); ii++) {
						listSetData.add(makeSetCode(ii, setcodeX, 16));
						listSetData.add(makeSetCode(ii, setcodeY, 16));
					}

					// 1shot�ڂ̍��W���o���Ă���
					final long shot1X = m_mapConsDataForDevice.get(setcodeX).getRealValue();
					final long shot1Y = m_mapConsDataForDevice.get(setcodeY).getRealValue();

					long maxDist = -1;
					long maxId = 0;
					for (int ii = 1; ii < getStepNum(); ii++) {
						final long dx = Math.abs(m_mapConsDataForDevice.get(makeSetCode(ii, setcodeX, 16)).
								getRealValue() - shot1X);
						final long dy = Math.abs(m_mapConsDataForDevice.get(makeSetCode(ii, setcodeY, 16)).
								getRealValue() - shot1Y);

						final long dist = dx * dx + dy * dy;
						if (dist > maxDist) {
							maxDist = dist;
							maxId = ii;
						}
					}

					final long lSetCodeMain = Long.parseLong(sFDCAlignmentMain, 16) + maxId;
					final long lSetCodeScan = Long.parseLong(sFDCAlignmentScan, 16) + maxId;
					setConsDataValue(CommonUtil.toHexString(lSetCodeMain, 5), "1");
					setConsDataValue(CommonUtil.toHexString(lSetCodeScan, 5), "1");
				}
			}
		}
		return true;
	}

	/**
	 * Performs checking of duplicated setcodes for JobDataEditor Code column.
	 * 
	 * @return mapDataError
	 */
	private Map<String, List<String>> checkDuplicateSetCode() {
		final int iMaxJobDataEditorRows = 64;
		final long lMargin = 0x5;
		final String sCode = "03000";
		final String[] asJobEditorSetCodes = new String[iMaxJobDataEditorRows];
		final HashMap<Long, Integer> keys = new HashMap<Long, Integer>();
		final Map<String, List<String>> mapErrorMessage = new HashMap<String, List<String>>();
		final List<String> listErrorMessageCode = new LinkedList<String>();

		for (int ii = 0; ii < iMaxJobDataEditorRows; ii++) {
			final String sSetCode = makeSetCode(ii, sCode, lMargin);
			asJobEditorSetCodes[ii] = sSetCode;
		}

		long lSetCode = 0;
		for (int ii = 0; ii < iMaxJobDataEditorRows; ii++) {
			lSetCode = getProcessConsData(asJobEditorSetCodes[ii]).getRealValue();

			if (!keys.containsKey(lSetCode)) {
				keys.put(lSetCode, ii);
				continue;
			}
			listErrorMessageCode.add(asJobEditorSetCodes[ii]);
		}

		mapErrorMessage.put(JobEditConst.ERROR_DUPLICATED_SETCODE, listErrorMessageCode);
		return mapErrorMessage;
	}
	
	/**
	 * Performs data adjustment for Process Control Tab data.
	 */
	private void adjustProcessControlTab() {
		m_FunctionChecker = NameService.getConsoleServiceFactory().getFunctionCheckerService();
		final boolean bShotChoiceExpo =
				m_FunctionChecker.isFunctionEnabled(ShotChoiceExposureChecker.class.getCanonicalName());
		final String sShotChoiceExposureOnOffSetCode = "12610";

		if (!bShotChoiceExpo) {
			final AbstractConsoleData consData = m_mapConsDataForProcess.get(sShotChoiceExposureOnOffSetCode);
			if (null != consData) {
				consData.setRealValue(0);
			}
		}

		adjustIllMultiTableForSave();
	}
	
	/**
	 * Performs data adjustment for Ill Multi Table.
	 */
	private void adjustIllMultiTableForSave() {
		final String sIllAutoAdjustSetCode = "30348";
		final String sIllMultiTableSetCode = "303DE";
		final boolean bIsIllAutoAdjustDisable = 0 == m_mapConsDataForProcess.get(sIllAutoAdjustSetCode).getRealValue();
		final boolean bIsIllAutoAdjustModeNotUse = 2 == m_mapConsDataForProcess.get("100AB").getRealValue();
		
		if (bIsIllAutoAdjustDisable || bIsIllAutoAdjustModeNotUse) {
			final AbstractConsoleData consData = m_mapConsDataForProcess.get(sIllMultiTableSetCode);
			if (null != consData) {
				consData.setRealValue(0);
			}
		}
	}

	/**
	 * Checks if Two Bend Use Setcode value is enabled.
	 * 
	 * @return true if Enabled, otherwise false
	 */
	private boolean isTwoBendUse() {
		final String sSetcodeTwoBendUse = "36003";
		final AbstractConsoleData data = m_mapConsDataForProcess.get(sSetcodeTwoBendUse);
		
		if (data == null) {
			return false;
		} else {
			return 1 == data.getRealValue();
		}
	}

	/**
	 * Performs data adjustment for Mask Bend Particle Inspection Tab data.
	 */
	private void adjustMaskBendParticleInspectionTab() {
		boolean bTwoBendUse = true;
		final String sBoxBendAutoExchangeSetCode = "37162";
		
		if (!isTwoBendUse()) {
			bTwoBendUse = false;
		}

		if (!bTwoBendUse) {
			final AbstractConsoleData consData = m_mapConsDataForProcess.get(sBoxBendAutoExchangeSetCode);
			
			if (consData != null) {
				consData.setRealValue(0);
			}
		}
	}

	/**
	 * Perform checking if Small Alignment Mark is Enabled or Disabled.
	 * 
	 * @return true if Enabled, otherwise false
	 */
	private boolean isSmallAlignmentMark() {
		final String sBoxFineAaMarkTypeSetCode = "13250";
		final int iFineMarkTypeSingle20Cross = 151;
		final int iFineMarkTypeMulti20Cross = 152;
		final int iFineAAMarkType = (int) m_mapConsDataForProcess.get(sBoxFineAaMarkTypeSetCode).getRealValue();

		if (iFineAAMarkType == iFineMarkTypeSingle20Cross
				|| iFineAAMarkType == iFineMarkTypeMulti20Cross) {
			return true;
		}
		return false;
	}

	/**
	 * Perform data adjustments for PlateAA tab.
	 */
	private void adjustPlateAATab() {
		m_FunctionChecker = NameService.getConsoleServiceFactory().getFunctionCheckerService();
		final boolean bFullSHotAASearchLicense =
				m_FunctionChecker.isFunctionEnabled(FullShotAASearchChecker.class.getCanonicalName());
		final int iSmallAlignmentMarkOn = 1;
		final int iSmallAlignmentMarkOff = 0;
		final int iExpoMode = (int) m_mapConsDataForDevice.get(JobEditConst.EXPO_MODE_SETCODE).getRealValue();
		final String sFullShotAASearchSetCode = "1063E";
		final String sSmallAlignmentMarkSetCode = "13DF0";

		if (!bFullSHotAASearchLicense
				|| RecipeConst.EXPOMODE_EDGE == iExpoMode
				|| RecipeConst.EXPOMODE_PARTIAL == iExpoMode
				|| RecipeConst.EXPOMODE_FREELAYOUT == iExpoMode) {
			final AbstractConsoleData consData = m_mapConsDataForProcess.get(sFullShotAASearchSetCode);
			if (consData != null) {
				consData.setRealValue(0);
			}
		}

		final AbstractConsoleData consSmallAlignment = m_mapConsDataForProcess.get(sSmallAlignmentMarkSetCode);
		if (consSmallAlignment != null) {
			if (isSmallAlignmentMark()) {
				consSmallAlignment.setRealValue(iSmallAlignmentMarkOn);
			} else {
				consSmallAlignment.setRealValue(iSmallAlignmentMarkOff);
			}
		}
	}
	
	/**
	 * Updates Defocus Measure Interval.
	 */
	private void updateDefocusMeasureInterval() {
		final long lSecMin = 60;
		final long lSecHour = 3600;
		final long lMulliUnit = 1000;
		final String sDefocusMeasureInterval = "05101";

		long lInterval = m_mapConsDataForProcess.get(sDefocusMeasureInterval).getRealValue();
		final long lHour = lInterval / (lSecHour * lMulliUnit);
		final long lMin = (lInterval - lSecHour * lMulliUnit * lHour) / (lSecMin * lMulliUnit);

		lInterval = lHour * lSecHour * lMulliUnit + lMin * lSecMin * lMulliUnit;
		m_mapConsDataForProcess.get(sDefocusMeasureInterval).setRealValue(lInterval);
		
		return;
	}
	
	/**
	 * Updates OAS Z Measurement Home Sensor Offset.
	 */
	private void updateOASZMeasHomeSensorOffset() {
		final String sOASMachineHomeSensorOffsetName = "20E0E";
		final int iHybridMode =
				(int) m_mapConsDataForProcess.get(OasTabConst.SetCode.HYBRID_MODE.getSetCode()).getRealValue();
		
		if (iHybridMode != 0) {
			return;
		}
		
		final AbstractConsoleData consData = m_mapConsDataForProcess.get(sOASMachineHomeSensorOffsetName);
		if (consData instanceof ConsoleDataDouble) {
			final double dValue = ((ConsoleDataDouble) consData).getValue();
			((ConsoleDataDouble) m_mapConsDataForProcess.get(
					OasTabConst.SetCode.OAS_TAB_HOME_SENSOR_OFFSET_NAME)).setValue(dValue);
		}
	}

	/**
	 * Perform data adjustments for OAS Tab.
	 */
	private void adjustOASTab() {
		if (isOASParanemic()) {
			updateDefocusMeasureInterval();
			
			updateOASZMeasHomeSensorOffset();
		} else {
			for (int ii = 0; ii < ConditionPanelSetCode.SHOT_SELECT.values().length; ii++) {
				final int iBoxShot = 
						(int) m_mapConsDataForProcess.get(ConditionPanelSetCode.SHOT_SELECT.getSetCode(ii))
						.getRealValue();
				if (iBoxShot != 0) {
					m_mapConsDataForProcess.get(ConditionPanelSetCode.SHOT_SELECT.getSetCode(ii)).setRealValue(0);
				}
			}
			updateDefocusMeasureInterval();
			updateOASZMeasHomeSensorOffset();
		}
	}

	/**
	 * Force values for Mask Layout's VS and CP.
	 */
	private void forceValueForMaskLayoutVSCP() {
		final int iExpoMode = (int) getDeviceConsData(JobEditConst.EXPO_MODE_SETCODE).getRealValue();
		if (iExpoMode == RecipeConst.EXPOMODE_FOCUS) {
			final DecimalFormat df = new DecimalFormat();
			df.applyPattern("0");
			final int iMinMaxFractionDigits = 5;
			df.setMaximumFractionDigits(iMinMaxFractionDigits);
			df.setMinimumFractionDigits(iMinMaxFractionDigits);

			final String sVSData = df.format(NameService.getConsoleServiceFactory()
					.getUMConstService().getPatternBasePositionAdjustmentVS());
			final String sVSPre = "32120";
			final String sVSFine = "32121";
			setConsDataValue(sVSPre, sVSData);
			setConsDataValue(sVSFine, sVSData);

			final String sCPData = df.format(NameService.getConsoleServiceFactory()
					.getUMConstService().getPatternBasePositionAdjustmentCP());
			final String sCPPre = "22001";
			final String sCPFine = "22005";
			setConsDataValue(sCPPre, sCPData);
			setConsDataValue(sCPFine, sCPData);
		}
	}
	
	/**
	 * Checks if Edge Mode AFC Fast is enabled.
	 * 
	 * @return true if enabled, otherwise false
	 */
	public boolean isEdgeModeAFCFast() {
		boolean bEdgeModeAFCFast = false;
		m_FunctionChecker = NameService.getConsoleServiceFactory().getFunctionCheckerService();
		bEdgeModeAFCFast = m_FunctionChecker.isFunctionEnabled(EdgeModeAFCFastChecker.class.getCanonicalName());
		return bEdgeModeAFCFast;
	}
	
	/**
	 * Force value for Edge Mode AFC Fast.
	 */
	private void setForceEdgeModeAFCFastOff() {
		final AbstractConsoleData consData = getProcessConsData("12596");
		final int iEdgeModeAFCFast = (int) consData.getRealValue();
		
		// �ݒ肳��Ă���l��OFF�łȂ����OFF�ɂ���
		if (0 != iEdgeModeAFCFast) {
			consData.setRealValue(0);
		}
	}

	/**
	 * Data adjustments for Plate AFC Tab.
	 */
	private void adjustPlateAfcTab() {
		controlAllShotAFCItem();
		controlAFCProc();
		controlPlateFocusInterlock();
		controlLastShotAFC();
		controlOASFocusInterlock();
	}
	
	/**
	 * ADC/FDC�^�u�Őݒ肳��Ă���ADCMode���擾����B
	 *
	 * @return ADCMode
	 */
	private int getADCMode() {
		return (int) getProcessConsData(RecipeConst.ADCMODE_NAME).getRealValue();
	}

	/**
	 * Adjust data for All Shot AFC item.
	 */
	private void controlAllShotAFCItem() {
		// OFF/ON�ݒ�l
		final int iValueOFF = 0;
		final int iValueON = 1;
		final int iHybridMode = (int) getProcessConsData(JobEditConst.OAS_HYBRID_MODE_SETCODE).getRealValue();
		final boolean bUseOAS = (iHybridMode != 0) && !isOASZeroLayerMarkAlignmentOrAmfMeas();
		m_FunctionChecker = NameService.getConsoleServiceFactory().getFunctionCheckerService();
		final boolean bOASUnitTypeParanemic =
				m_FunctionChecker.isFunctionEnabled(OASUnitTypeParanemicChecker.class.getCanonicalName());
		final boolean bOASUnitTypeShotMove =
				m_FunctionChecker.isFunctionEnabled(OASUnitTypeShotMoveChecker.class.getCanonicalName());
		//final boolean bOASUnitTypeShotMove =
		//  m_FunctionChecker.isFunctionEnabled(OASUnitTypeChecker.class.getCanonicalName(),
		//          OASUnitTypeSubFeature.SHOT_MOVE);
		
		final int iAllShotAFCValue = (int) getProcessConsData(RecipeConst.SETCODE_ALL_SHOT_AFC_STRING).getRealValue();

		if (bUseOAS && iValueON != iAllShotAFCValue) {
			setConsDataValue(RecipeConst.SETCODE_ALL_SHOT_AFC_STRING, String.valueOf(iValueON));
		}

		final String sAllShotAfcProcSetCode = "12A10";
		final int iExpoMode = (int) getDeviceConsData(JobEditConst.EXPO_MODE_SETCODE).getRealValue();

		if (iValueOFF == iAllShotAFCValue) {
			final int iNORMAL = 0;
			setConsDataValue(sAllShotAfcProcSetCode, String.valueOf(iNORMAL));
		} else if (iValueON == iAllShotAFCValue
				&& bUseOAS
				&& bOASUnitTypeParanemic) {
			final int iFAST = 1;
			setConsDataValue(sAllShotAfcProcSetCode, String.valueOf(iFAST));
		} else if (iValueON == iAllShotAFCValue
				&& 0 != iHybridMode
				&& bOASUnitTypeShotMove
				&& RecipeConst.ADCMODE_OPTI50 == getADCMode()
				&& JobEditConst.EXPO_MODE_NORMAL == iExpoMode) {
			final int iFAST = 1;
			setConsDataValue(sAllShotAfcProcSetCode, String.valueOf(iFAST));
		}
	}

	/**
	 * Adjust data for Plate Focus interlock.
	 */
	private void controlPlateFocusInterlock() {
		final int iHybridMode = (int) getProcessConsData(JobEditConst.OAS_HYBRID_MODE_SETCODE).getRealValue();
		final boolean bUseOAS = (iHybridMode != 0) && !isOASZeroLayerMarkAlignmentOrAmfMeas();
		final String sEachShotAFCAverageCompSetCode = "12A20";
		final int iPlateFocusInterlockValue =
				(int) getProcessConsData(RecipeConst.PLATE_FOCUS_INTERLOCK_SETCODE).getRealValue();
		final int iOFF = 0;
		
		if (bUseOAS) {
			if (isOASEachShotAFCAveCompEnable()) {
				final int iEachShotAFCAveCompValue =
						(int) getProcessConsData(sEachShotAFCAverageCompSetCode).getRealValue();

				if (iEachShotAFCAveCompValue != iPlateFocusInterlockValue) {
					setConsDataValue(RecipeConst.PLATE_FOCUS_INTERLOCK_SETCODE,
							String.valueOf(iEachShotAFCAveCompValue));
				}
			} else {
				setConsDataValue(RecipeConst.PLATE_FOCUS_INTERLOCK_SETCODE, String.valueOf(iOFF));
			}
		}

		if (iPlateFocusInterlockValue == iOFF && !isOASEachShotAFCAveCompEnable()) {
			setConsDataValue(sEachShotAFCAverageCompSetCode, String.valueOf(iOFF));
		}
	}
	
	/**
	 * Retrieve value of Step No.
	 *
	 * @return StepNo
	 */
	private int getStepNo() {
		final AbstractConsoleData data = getDeviceConsData(JobEditConst.STEPNO_SETCODE);
		return (int) data.getRealValue();
	}
	
	/**
	 * Retrieve value of XStep Num.
	 *
	 * @return XStepNum
	 */
	private int getXStepNum() {
		final AbstractConsoleData data = getDeviceConsData(JobEditConst.XSTEP_NUM_SETCODE);
		return (int) data.getRealValue();
	}

	/**
	 * Retrieve value of YStep Num.
	 *
	 * @return YStepNum
	 */
	private int getYStepNum() {
		final AbstractConsoleData data = getDeviceConsData(JobEditConst.YSTEP_NUM_SETCODE);
		return (int) data.getRealValue();
	}
	
	/**
	 * Get Step num depending on Exposure Mode.
	 *
	 * @return StepNum
	 */
	private int getStepNum() {
		final int iExpoMode = (int) getDeviceConsData(JobEditConst.EXPO_MODE_SETCODE).getRealValue();
		int iStepNum = 0;

		switch (iExpoMode) {
		case RecipeConst.EXPOMODE_FREELAYOUT:
		case RecipeConst.EXPOMODE_FOCUS:
		case RecipeConst.EXPOMODE_SQUARE:
		case RecipeConst.EXPOMODE_LATTICE1:
		case RecipeConst.EXPOMODE_LATTICE2:
		case RecipeConst.EXPOMODE_ABBEMY:
		case RecipeConst.EXPOMODE_ABBEC:
			iStepNum = getStepNo();
			break;

		default:
			iStepNum = getXStepNum() * getYStepNum();
			break;
		}

		return iStepNum;
	}

	/**
	 * OAS�^�u�Őݒ肳��Ă���AS FDC�̒l���擾����B
	 *
	 * @return AS FDC�̒l
	 */
	private int getASFDC() {
		final String sAsFDCSetCode = "12C83";
		final AbstractConsoleData abs = getProcessConsData(sAsFDCSetCode);
		if (abs != null) {
			return (int) abs.getRealValue();
		}
		return 0;
	}
	
	/**
	 * AFC�΂���␳�@�\���L�����ǂ����B
	 * @return true:�L��
	 */
	private boolean isOASEachShotAFCAveCompEnable() {
		final int iHybridMode = (int) getProcessConsData(JobEditConst.OAS_HYBRID_MODE_SETCODE).getRealValue();
		m_FunctionChecker = NameService.getConsoleServiceFactory().getFunctionCheckerService();
		final boolean bIsOASFDC = m_FunctionChecker.isFunctionEnabled(OASFDCChecker.class.getCanonicalName());
		final boolean bIsOASEachShotAFCAveComp =
				m_FunctionChecker.isFunctionEnabled(OASEachShotAFCAveCompChecker.class.getCanonicalName());
		
		final int iSetcode = Integer.parseInt(SETCODE.FDC_ALIGNMENT_POSITION.getName(), 16);
		final long lMargin = SETCODE.FDC_ALIGNMENT_POSITION.getMargin();

		// FDC Alignment Position�̒l
		final long lValueFDCAlignmentNone = 0;
		final long lValueFDCAlignmentP2On = 2;
		boolean bExistP2ON = false;

		// Recipe�̗L����Shot���������f�[�^���Q�Ƃ���
		final int iMaxStepNum = getStepNum();
		for (int iDataCount = 0; iDataCount < iMaxStepNum; iDataCount++) {
			final String sSetcode = Long.toHexString(iSetcode + iDataCount * lMargin).toUpperCase();
			final long lValue = getConsLong(sSetcode).getValue();

			// FDC Alignment Position�eShot�̐ݒ�̂��� P2=ON��1Shot�ȏ㑶�݂��AP2, None�̂����ꂩ�Őݒ肳��Ă���ꍇ�L��
			if (lValueFDCAlignmentNone == lValue) {
				continue;
			} else if (lValueFDCAlignmentP2On == lValue) {
				bExistP2ON = true;
				continue;
			} else {
				return false;
			}
		}
		// // FDC Alignment Position P2=ON��1Shot���Ȃ��ꍇfalse�ŕԂ�
		if (!bExistP2ON) {
			return false;
		}

		final boolean bUseOAS = 0 != iHybridMode && !isOASZeroLayerMarkAlignmentOrAmfMeas();
		return bUseOAS
				&& bIsOASFDC
				&& bIsOASEachShotAFCAveComp
				&& 0 != getASFDC();
	}

	/**
	 * Control OAS Focus Interlock.
	 */
	private void controlOASFocusInterlock() {
		final int iHybridMode = (int) getProcessConsData(JobEditConst.OAS_HYBRID_MODE_SETCODE).getRealValue();
		final boolean bUseOAS = (iHybridMode != 0) && !isOASZeroLayerMarkAlignmentOrAmfMeas();
		
		if (!bUseOAS) {
			setConsDataValue(JobEditConst.SETCODE_OAS_FOCUS_INTERLOCK, String.valueOf(0));
		}
	}
	
	/**
	 * Control AFC Proc.
	 */
	private void controlAFCProc() {
		final int iHybridMode = (int) getProcessConsData(JobEditConst.OAS_HYBRID_MODE_SETCODE).getRealValue();
		final boolean bUseOAS = (iHybridMode != 0) && !isOASZeroLayerMarkAlignmentOrAmfMeas();
		final int iNonTilt = 1;
		
		final int iAfcProcValue = (int) getProcessConsData("22010").getRealValue();
		// Use OAS�L���@���@AFC Proc.=Non TIlt�Ȃ��Tilt�ɂ���
		if (bUseOAS && iNonTilt != iAfcProcValue) {
			setConsDataValue("22010", String.valueOf(iNonTilt));
		}
	}
	
	/**
	 * Data adjustment for Last Shot AFC.
	 */
	private void controlLastShotAFC() {
		final int iHybridMode = (int) getProcessConsData(JobEditConst.OAS_HYBRID_MODE_SETCODE).getRealValue();
		final boolean bUseOAS = (iHybridMode != 0) && !isOASZeroLayerMarkAlignmentOrAmfMeas();
		final int iLastShotAFC = (int) getProcessConsData(RecipeConst.SETCODE_LAST_SHOT_AFC_STRING).getRealValue();
		final int iOFF = 0;

		if (bUseOAS && iOFF != iLastShotAFC) {
			setConsDataValue(RecipeConst.SETCODE_LAST_SHOT_AFC_STRING, String.valueOf(iOFF));
		}
	}

	/**
	 * �R���\�[���f�[�^�̒l�ݒ�B
	 *
	 * @param sSetCode �ݒ�f�[�^�R�[�h
	 * @param sValue �ύX�l
	 */
	private void setConsDataValue(final String sSetCode, final String sValue) {
		final AbstractConsoleData consData = getProcessConsData(sSetCode);
		if (null == consData) {
			ConsoleLogger.getLogger().
				warning("[ProcessDataRecipeValidator] setConsDataValue() : not found console data(" + sSetCode + ").");
		}

		String sData = sValue;
		if (consData instanceof ConsoleDataDouble) {
			if (0 == sData.trim().length()) {
				sData = "0";
			}

			((ConsoleDataDouble) consData).setValue(Double.parseDouble(sData));
		} else if (consData instanceof ConsoleDataLong) {
			if (0 == sData.trim().length()) {
				sData = "0";
			}

			((ConsoleDataLong) consData).setValue(Long.parseLong(sData));
		} else if (consData instanceof ConsoleDataString) {
			((ConsoleDataString) consData).setValue(sData);
		}
	}
}

