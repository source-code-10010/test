/*-----------------------------------------------------------
 - �X�}�[�g�R���\�[��(Smart Console)						-
 - 		Console software for MPAsp series.					-
 -															-
 - FPD Production Equipment PLM Center 4					-
 - Copyright (C) 2009 - 2018 Canon Inc. All Rights Reserved	-
 ------------------------------------------------------------*/
package canon.lcd.console.service.recipe.check;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import canon.lcd.console.service.AbstractConsoleData;
import canon.lcd.console.service.recipe.ConsoleRecipeInfoManagerAccessIF;
import canon.lcd.console.service.recipe.JobEditConst;
import canon.lcd.console.service.recipe.RecipeConst;
import canon.lcd.console.service.recipe.ValueWrongCheckProxy;
import canon.lcd.console.serviceFactory.NameService;
import canon.lcd.console.utility.CommonUtil;

/**
 * Common recipe validator.
 */
public abstract class AbstractCommonRecipeValidator {

	/**
	 * Setcode length.
	 */
	private final int m_iSetcodeLength = 5;

	/**
	 * Consistency check instance (For ProcessDataRecipeValidator, instance is ConsistencyCheckForProcess).
	 */
	private ConsistencyCheckIF m_ConsistencyCheck;

	/**
	 * Console recipe manager access instance.
	 */
	private ConsoleRecipeInfoManagerAccessIF m_ConsoleRecipeInfoManagerAccess = null;

	/**
	 * Sets consistency check instance.
	 * 
	 * @param consistencyCheck Consistency check instance
	 */
	public void setConsistencyCheck(final ConsistencyCheckIF consistencyCheck) {
		m_ConsistencyCheck = consistencyCheck;
	}

	/**
	 * Gets consistency check instance.
	 * 
	 * @return ConsistencyCheck instance
	 */
	public ConsistencyCheckIF getConsistencyCheck() {
		return m_ConsistencyCheck;
	}

	/**
	 * Checks if DeviceData or ProcessData is on execution.
	 * 
	 * @param sDevice Device name
	 * @param sProcess Process name
	 * @return isExecute
	 */
	public boolean isExecute(final String sDevice, final String sProcess) {
		m_ConsoleRecipeInfoManagerAccess = NameService.getConsoleServiceFactory().getRecipeInfoAccessService();
		return m_ConsoleRecipeInfoManagerAccess.isExecute(sDevice, sProcess);
	}

	/**
	 * Get corresponding error message for ValueWrongCheckProxy object.
	 * 
	 * @param checkProxy Value wrong check object
	 * @return Error message
	 */
	public String getDataCheckErrorMessage(final ValueWrongCheckProxy checkProxy) {
		final StringBuilder builder = new StringBuilder(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE);
		builder.append(System.getProperty("line.separator"));
		final String sErrorMessage;

		switch (checkProxy.getErrorNo()) {
		case RecipeConst.VALUE_ERROR_XSMB_POSITION:
			sErrorMessage = JobEditConst.ERROR_XSMB_POSITION;
			break;

		case RecipeConst.VALUE_ERROR_YSMB_DIRECTION:
			sErrorMessage = JobEditConst.ERROR_YSMB_DIRECTION;
			break;

		case RecipeConst.VALUE_ERROR_FRONT_OVERLAP_DUPLICATE:
			sErrorMessage = JobEditConst.ERROR_FRONT_OVERLAP_DUPLICATE;
			break;

		case RecipeConst.VALUE_ERROR_FRONT_OVERLAP_LIMIT:
			sErrorMessage = JobEditConst.ERROR_FRONT_OVERLAP_LIMIT;
			break;

		case RecipeConst.VALUE_ERROR_LEFT_OVERLAP_DUPLICATE:
			sErrorMessage = JobEditConst.ERROR_LEFT_OVERLAP_DUPLICATE;
			break;

		case RecipeConst.VALUE_ERROR_LEFT_OVERLAP_LIMIT:
			sErrorMessage = JobEditConst.ERROR_LEFT_OVERLAP_LIMIT;
			break;

		case RecipeConst.VALUE_ERROR_YSMB_SIDE:
			sErrorMessage = JobEditConst.ERROR_YSMB_SIDE;
			break;

		case RecipeConst.VALUE_ERROR_XSMB_SIDE:
			sErrorMessage = JobEditConst.ERROR_XSMB_SIDE;
			break;

		case RecipeConst.VALUE_ERROR_MX_COMP_CHANGE:
			sErrorMessage = JobEditConst.ERROR_MX_COMP_CHANGE;
			break;
		case RecipeConst.VALUE_ERROR_2ND_XSMB_USE:
			sErrorMessage = JobEditConst.ERROR_2ND_XSMB_USE;
			break;
		default:
			sErrorMessage = "";
			break;
		}

		// Step�ԍ������b�Z�[�W�ɖ��ߍ���
		builder.append(sErrorMessage.replace(JobEditConst.REPLACE_STRING, Integer.toString(checkProxy.getShotNo())));
		
		return builder.toString();
	}

	/**
	 * Replace console data.
	 * 
	 * @param map Calculated map
	 * @param mapConsData Map to be updated
	 */
	protected void replaceAllConsData(final Map<String, AbstractConsoleData> map,
			final Map<String, AbstractConsoleData> mapConsData) {

		// backup value�������Ȃ��悤�ɐݒ�f�[�^�R�[�h�Ō������Đ��l�̂݃Z�b�g����B
		for (final AbstractConsoleData consData : map.values()) {
			final String sName = consData.getName();
			mapConsData.get(sName).setRealValue(consData.getRealValue());
		}
	}

	/**
	 *  Creates setcode list for column.
	 *  
	 * @param sSetcode Setcode name
	 * @param lMargin Setcode margin
	 * @param iMaxRows Maximum number of rows
	 * @return Setcode list
	 */
	protected List<String> createColumnSetCodeList(final String sSetcode, final long lMargin, final int iMaxRows) {
		final List<String> listSetCode = new LinkedList<String>();
		
		for (int ii = 0; ii < iMaxRows; ii++) {
			listSetCode.add(makeSetCode(ii, sSetcode, lMargin));
		}
		
		return listSetCode;
	}

	/**
	 * �ݒ�f�[�^�R�[�h�̐����B
	 * �s�ԍ��A�Ԋu�l����Z�o�����ݒ�f�[�^�R�[�h������(�啶��)�𐶐����ĕԂ��B
	 *
	 * @param iRow �s�ԍ�
	 * @param sSetCode �ݒ�f�[�^�R�[�h
	 * @param lMargin �Ԋu�l
	 * @return ������̐ݒ�f�[�^�R�[�h
	 */
	protected String makeSetCode(final int iRow, final String sSetCode, final long lMargin) {
		// �f�[�^�Ȃ�
		if (null == sSetCode || sSetCode.isEmpty()) {
			return sSetCode;
		}

		final long lDev = iRow * lMargin;

		if (0 < lDev) {
			final long lSetCode = Long.parseLong(sSetCode, 16) + lDev;
			return CommonUtil.toHexString(lSetCode, m_iSetcodeLength);
		}

		return sSetCode;
	}
}
