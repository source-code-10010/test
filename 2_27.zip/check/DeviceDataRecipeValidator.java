/*-----------------------------------------------------------
 - �X�}�[�g�R���\�[��(Smart Console)						-
 - 		Console software for MPAsp series.					-
 -															-
 - FPD Production Equipment PLM Center 4					-
 - Copyright (C) 2009 - 2018 Canon Inc. All Rights Reserved	-
 ------------------------------------------------------------*/
package canon.lcd.console.service.recipe.check;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import canon.lcd.console.service.recipe.JobCalculationManagerAccessServiceIF;
import canon.lcd.console.service.recipe.JobEditConst;
import canon.lcd.console.service.recipe.RecipeConst;
import canon.lcd.console.service.recipe.ValueWrongCheckProxy;
import canon.lcd.console.service.recipe.impl.check.ValueWrongCheck;
import canon.lcd.console.serviceFactory.NameService;
import canon.lcd.console.utility.CommonConst;
import canon.lcd.console.utility.CommonUtil;
import canon.lcd.g10lib.utility.log.ConsoleLogger;
import canon.lcd.console.consoleData.ConsBase;
import canon.lcd.console.consoleData.ConsoleDataUtils;
import canon.lcd.console.service.AbstractConsoleData;
import canon.lcd.console.service.funcchecker.FunctionCheckerIF;
import canon.lcd.console.service.funcchecker.checker.SlitMaskingBladeChecker;
import canon.lcd.console.service.funcchecker.checker.XSlitMaskingBladeChecker;

/**
 * Class that validates Device Data Recipe.
 */
public class DeviceDataRecipeValidator extends AbstractCommonRecipeValidator {
	
	/**
	 * Consistency check instance (For DeviceDataRecipeValidator, instance is ConsistencyCheckForDevice).
	 */
	private ConsistencyCheckIF m_ConsistencyCheck = null;
	
	/**
	 * Job Calculation Manager Access Service instance.
	 */
	private JobCalculationManagerAccessServiceIF m_JobCalculationManagerAccessService = null;

	/**
	 * Function Checker instance.
	 */
	private FunctionCheckerIF m_FunctionChecker = null;

	/**
	 * Contains mapping of setcode and value for DeviceData.
	 */
	private Map<String, AbstractConsoleData> m_mapConsData = null;

	/**
	 * Instance for ValueWrongCheck.
	 */
	ValueWrongCheck m_valueWrongCheck = null;

	/**
	 * FreeLayoutPlate Setcodes.
	 */
	public enum FreeLayoutPlateSETCODE {
		/**
		 * �X�e�b�v��X�ʒu�B
		 */
		STEP_POS_X("02030", 0x3),
		/**
		 * �X�e�b�v��Y�ʒu�B
		 */
		STEP_POS_Y("02031", 0x3),
		/**
		 * �}�X�N�p�^�[���B
		 */
		PATTERN("02032", 0x3),
		/**
		 * �p�l���O���[�v�B
		 */
		PANEL_GR("12704", 0x7),
		/**
		 * �d�˕�:Left�����B
		 */
		OVERLAP_XSMB_LEFT("02490", 0x1),
		/**
		 * �d�˕�:Right�����B
		 */
		OVERLAP_XSMB_RIGHT("024C0", 0x1),
		/**
		 * �d�˕�:Back�����B
		 */
		OVERLAP_YSMB_BACK("02400", 0x1),
		/**
		 * �d�˕�:Front�����B
		 */
		OVERLAP_YSMB_FRONT("02430", 0x1),
		/**
		 * YSMB�F�d�Ȃ�����B
		 */
		YSMB_SIDE("23B00", 0x10),
		/**
		 * YSMB�FFront�����̏d�Ȃ�X�e�b�v.
		 */
		FROTN_OVERLAP_STEP("02730", 0x1),
		/**
		 * XSMB�F�d�Ȃ�����B
		 */
		XSMB_SIDE("02460", 0x1),
		/**
		 * XSMB�FLeft�����̏d�Ȃ�X�e�b�v.
		 */
		LEFT_OVERLAP_STEP("02760", 0x1),
		/**
		 * 2nd XSMB�F�d�Ȃ�����B
		 */
		SECOND_XSMB_SIDE("02A20", 0x1),
		/**
		 * XMB�FOutside Edge�����ʒu�v�Z.
		 */
		XMB_POSITION("02790", 0x1);

		/**
		 * �ݒ�f�[�^�R�[�h�B
		 */
		private final String m_sName;

		/**
		 * �ݒ�f�[�^�R�[�h�̊Ԋu�B
		 */
		private final long m_lMargin;

		/**
		 * �R���X�g���N�^�[�B
		 *
		 * @param sName ����(�ݒ�f�[�^�R�[�h)
		 * @param lMargin �ݒ�f�[�^�R�[�h�̊Ԋu
		 */
		FreeLayoutPlateSETCODE(final String sName, final long lMargin) {
			m_sName = sName;
			m_lMargin = lMargin;
		}

		/**
		 * ����(�ݒ�f�[�^�R�[�h)�̎擾�B
		 *
		 * @return ����(�ݒ�f�[�^�R�[�h)
		 */
		public String getName() {
			return m_sName;
		}

		/**
		 * �ݒ�f�[�^�R�[�h�̊Ԋu���擾�B
		 *
		 * @return �ݒ�f�[�^�R�[�h�̊Ԋu
		 */
		public long getMargin() {
			return m_lMargin;
		}
	}

	/**
	 * DeviceDataRecipeValidator constructor.
	 */
	public DeviceDataRecipeValidator() {
		initialize();
	}

	/**
	 * Performs calc job for DeviceData.
	 * 
	 * @param sDeviceName Device Name
	 * @param consData Mapping of setcode and value for DeviceData
	 * @return Mapping of calculated Setcode and value
	 */
	public Map<String, AbstractConsoleData> performCalcJobForDevice(final String sDeviceName, 
			final Map<String, AbstractConsoleData> consData) {
		m_JobCalculationManagerAccessService = 
				NameService.getConsoleServiceFactory().getJobCalculationManagerAccessService();
		return m_JobCalculationManagerAccessService.calcJobForDevice(sDeviceName, consData);
	}

	/**
	 * Performs check value wrong for DeviceData.
	 * 
	 * @param iExposureMode Exposure Mode
	 * @param bEnabledXSMB Check if XSMB checker is enabled
	 * @param bEnabledYSMB Check if YSMB checker is enabled
	 * @param mapConsData Mapping of setcode and value for DeviceData
	 * @return ValueWrongCheckProxy
	 */
	public ValueWrongCheckProxy performCheckValueWrong(final int iExposureMode,
			final boolean bEnabledXSMB,
			final boolean bEnabledYSMB,
			final Map<String, AbstractConsoleData> mapConsData) {
		final ValueWrongCheckProxy checkProxy = new ValueWrongCheckProxy(RecipeConst.VALUE_CHECK_OK);

		// FreeLayout�ȊO�̓`�F�b�N���ڂȂ�
		if (JobEditConst.EXPO_MODE_FREE != iExposureMode) {
			return checkProxy;
		}
		
		// SMB�@�\�̗����������̏ꍇ�̓`�F�b�N�ΏۊO
		if (!bEnabledYSMB && !bEnabledXSMB) {
			return checkProxy;
		}

		// �f�o�C�X��SMB�f�[�^�s���`�F�b�N
		final Map<String, ConsBase> mapConvertedMap = convertAbstractConsoleDataToConsBase(mapConsData);
		m_valueWrongCheck = new ValueWrongCheck();
		return m_valueWrongCheck.checkSMBDataValueForDevice(mapConvertedMap, true);
	}

	private Map<String, ConsBase> convertAbstractConsoleDataToConsBase(final Map<String, AbstractConsoleData> mapConsData) {
		final Map<String, ConsBase> mapData = new HashMap<String, ConsBase>();

		for (final Entry<String, AbstractConsoleData> entryConsData : mapConsData.entrySet()) {
			final ConsBase consBase = ConsoleDataUtils.setDataToConsData(entryConsData.getValue());

			if (null != consBase) {
				mapData.put(consBase.getName(), consBase);
			}
		}
		return mapData;
	}

	/**
	 * Validates DeviceData Recipe.
	 * 
	 * @param mapConsDataForDevice Mapping of setcode and value for device data
	 * @param sDeviceName Device name
	 * @param sProcessName Process name
	 * @return DeviceData error
	 */
	public Map<String, List<String>> validateDeviceDataRecipe(final Map<String, AbstractConsoleData> mapConsDataForDevice,
			final String sDeviceName, final String sProcessName) {
		final Map<String, List<String>> mapDeviceDataError = new HashMap<String, List<String>>();
		m_mapConsData = mapConsDataForDevice;

		// Perform consistency check
		m_ConsistencyCheck.checkConsistency(ConsistencyCheckIF.IDX_ALL, m_mapConsData);
		mapDeviceDataError.putAll(((ConsistencyCheckForDevice) m_ConsistencyCheck).getErrorSetCodeMap());
		if (mapDeviceDataError.size() != 0) {
			return mapDeviceDataError;
		}

		// Perform value range check
		mapDeviceDataError.putAll(performValueRangeCheck());
		if (mapDeviceDataError.size() != 0) {
			return mapDeviceDataError;
		}

		// Perform calcJob
		final Map<String, AbstractConsoleData> mapCalcData = performCalcJobForDevice(sDeviceName, m_mapConsData);
		replaceAllConsData(mapCalcData, m_mapConsData);

		// Perform check proxy
		m_FunctionChecker = NameService.getConsoleServiceFactory().getFunctionCheckerService();
		final ValueWrongCheckProxy checkProxy =
				performCheckValueWrong((int) m_mapConsData.get(JobEditConst.EXPO_MODE_SETCODE).getRealValue(),
				m_FunctionChecker.isFunctionEnabled(XSlitMaskingBladeChecker.class.getCanonicalName()),
				m_FunctionChecker.isFunctionEnabled(SlitMaskingBladeChecker.class.getCanonicalName()),
				m_mapConsData);
		final String sErrorMessage = getDataCheckErrorMessage(checkProxy);
		final List<String> listErrorSetCode = checkProxy.getErrorSetCodeList();
		mapDeviceDataError.put(sErrorMessage, listErrorSetCode);

		if (mapDeviceDataError.size() != 0) {
			return mapDeviceDataError;
		}

		return mapDeviceDataError;
	}

	/**
	 * Initialization of DeviceDataRecipeValidator.
	 */
	private void initialize() {
		m_ConsistencyCheck = new ConsistencyCheckForDevice();
		setConsistencyCheck(m_ConsistencyCheck);
	}

	/**
	 * Checks if at least one setcode is out of range.
	 * 
	 * @param listSetCode Setcode list
	 * @return DeviceData error
	 */
	private Map<String, List<String>> checkIfOutOfRange(final List<String> listSetCode) {
		final Map<String, List<String>> mapDeviceDataError = new HashMap<String, List<String>>();

		for (final String sSetCode : listSetCode) {
			if (m_mapConsData.containsKey(sSetCode)) {
				final AbstractConsoleData consData = m_mapConsData.get(sSetCode);

				if (consData.isOutOfRange()) {
					mapDeviceDataError.put(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE, Arrays.asList(consData.getName()));
					break;
				}
			} else {
				ConsoleLogger.getLogger().info("[checkIfOutOfRange] m_mapConsData does not contain: ["
						+ sSetCode + "]");
			}
		}

		return mapDeviceDataError;
	}

	/**
	 * �K�v���̐ݒ�R�[�h�쐬�����B<br>
	 * FreeLayout��ʂ�MaskLayout�e�[�u���͓���Ȃ̂ŃI�[�o�[���C�h����B<br>
	 * ����ȓ_�Ƃ́A�e�[�u����9�s�ڈȍ~�́A<br>
	 * ������ւ̐ݒ�f�[�^�����ʂ��ς��_�ł���B
	 *
	 * @param sSetCode �ݒ�R�[�h
	 * @param iMaxRowNum �ő��
	 * @param lMargin �}�[�W��
	 * @return �ݒ�R�[�h���X�g
	 */
	private final List<String> createDataForFreeLayoutMask(final String sSetCode, final int iMaxRowNum,
			final long lMargin) {
		final List<String> listSetCode = new LinkedList<String>();
		Long lSetCode = Long.parseLong(sSetCode, CommonConst.CAST_16TO10);
		
		// �ݒ�f�[�^�ύX�s
		final int iSetCodeChangeRow = 8;
		
		// �ݒ�f�[�^�ύX����Margin
		final long lChangeSetCodeMargin = 0x100;
		
		for (int ii = 0; ii < iMaxRowNum; ii++) {
		String sConvSetCode = Long.toHexString(lSetCode).toUpperCase();
		sConvSetCode = CommonUtil.convCharBfrFormat(sConvSetCode, CommonConst.SETCODE_LENGTH, "0");
		listSetCode.add(sConvSetCode);
		lSetCode += lMargin;
		
		// �ݒ�f�[�^�����p(9�s�ڂ���ݒ�f�[�^���قȂ�)
		if (ii == iSetCodeChangeRow) {
		lSetCode += lChangeSetCodeMargin;
		}
		}
		
		return listSetCode;
		}
	
	/**
	 * �K�v���̐ݒ�R�[�h�쐬�����B
	 *
	 * @param sSetCode �ݒ�R�[�h
	 * @param iMaxRowNum �ő�s��
	 * @param lMargin �}�[�W��
	 * @return �ݒ�R�[�h���X�g
	 */
	private List<String> createData(final String sSetCode, final int iMaxRowNum, final long lMargin) {
		final List<String> listSetCode = new LinkedList<String>();
		Long lSetCode = Long.parseLong(sSetCode, 16);

		for (int ii = 0; ii < iMaxRowNum; ii++) {
			final String sConvSetCode = CommonUtil.toHexString(lSetCode, 5);
			listSetCode.add(sConvSetCode);
			lSetCode += lMargin;
		}

		return listSetCode;
	}

	/**
	 * Creates partial layout column setcodes.
	 * 
	 * @return Setcode list
	 */
	private List<String> createPartialLayoutColumnSetCodeList() {
		final List<String> listSetCode = new LinkedList<String>();

		final int iXStepNum = (int) m_mapConsData.get(JobEditConst.XSTEP_NUM_SETCODE).getRealValue();

		for (int ii = 0; ii < iXStepNum; ii++) {
			listSetCode.add(JobEditConst.OVERLAPSIDE_ALLAY[ii]);
			listSetCode.add(JobEditConst.MB_POS_ALLAY_XL[ii]);
			listSetCode.add(JobEditConst.MB_POS_ALLAY_XR[ii]);
			listSetCode.add(JobEditConst.EXPO_SIZE_X_ARRAY[ii]);
			listSetCode.add(JobEditConst.STEP_POS_X_PARTIAL_SETCODE[ii]);
		}

		return listSetCode;
	}

	/**
	 * Creates partial layout row setcodes.
	 * 
	 * @return Setcode list
	 */
	private List<String> createPartialLayoutRowSetCodeList() {
		final List<String> listSetCode = new LinkedList<String>();

		final int iYStepNum = (int) m_mapConsData.get(JobEditConst.YSTEP_NUM_SETCODE).getRealValue();

		for (int ii = 0; ii < iYStepNum; ii++) {
			listSetCode.add(JobEditConst.ALIGNMENTPOS_ALLAY[ii]);
			listSetCode.add(JobEditConst.MB_POS_ALLAY_YB[ii]);
			listSetCode.add(JobEditConst.MB_POS_ALLAY_YF[ii]);
			listSetCode.add(JobEditConst.EXPO_SIZE_Y_ARRAY[ii]);
			listSetCode.add(JobEditConst.STEP_POS_Y_PARTIAL_SETCODE[ii]);
		}

		return listSetCode;
	}

	/**
	 * Creates free mask setcodes.
	 * 
	 * @return Setcode list
	 */
	private List<String> createFreeMaskSetCodeList() {
		final List<String> listSetCode = new LinkedList<String>();
		final String[] asFreeLayoutMaskSetCodeNo = { "020C0", "020C1", "020C2", "020C3", "020C4" };
		final int iFreeLayoutMaskRows = 12;
		final long lFreeLayoutMaskMargin = 0x10;

		for (int ii = 0; ii < asFreeLayoutMaskSetCodeNo.length; ii++) {
			listSetCode.addAll(createDataForFreeLayoutMask(asFreeLayoutMaskSetCodeNo[ii],
					iFreeLayoutMaskRows,
					lFreeLayoutMaskMargin));
		}

		listSetCode.addAll(Arrays.asList(JobEditConst.HALF_TONE_WIDTH_LEFT));
		listSetCode.addAll(Arrays.asList(JobEditConst.HALF_TONE_WIDTH_RIGHT));
		listSetCode.addAll(Arrays.asList(JobEditConst.HALF_TONE_WIDTH_BACK));
		listSetCode.addAll(Arrays.asList(JobEditConst.HALF_TONE_WIDTH_FRONT));

		listSetCode.add(JobEditConst.OVERLAP_TOLERANCE_SETCODE);

		return listSetCode;
	}

	/**
	 * Creates free plate setcodes.
	 * 
	 * @return Setcode list
	 */
	private List<String> createFreePlateSetCodeList() {
		final List<String> listSetCode = new LinkedList<String>();
		final int[] aiFreeLayoutPlateRowsGrid = { 1, 1, 1, 1, 1, 35, 36, 36, 36, 35, 36, 36, 36, 36, 36, 1};
		final long lFreeLayoutPlateMarginGrid = 0x1;
		final long lFreeLayoutPlateSetcode2ndXsmb = 0x03410;
		final int iFreeLayoutPlateRows = 36;

		final String[] asFreeLayoutPlateCodeFormatGridId = {
			JobEditConst.SETCODE_PLATE_LAYOUT,
			JobEditConst.SETCODE_X_STEP_NUM,
			JobEditConst.SETCODE_Y_STEP_NUM,
			RecipeConst.SETCODE_SHIFT_ALL_SHOT_X,
			RecipeConst.SETCODE_SHIFT_ALL_SHOT_Y,
			CommonUtil.LongToHexString(RecipeConst.SETCODE_Y_SPACE),
			CommonUtil.LongToHexString(RecipeConst.SETCODE_YSMB_SIDE_GRID),
			CommonUtil.LongToHexString(RecipeConst.SETCODE_FRONT_OVERLAP_GRID),
			CommonUtil.LongToHexString(RecipeConst.SETCODE_COLUMN),
			CommonUtil.LongToHexString(RecipeConst.SETCODE_X_SPACE),
			CommonUtil.LongToHexString(RecipeConst.SETCODE_XSMB_SIDE_GRID),
			CommonUtil.LongToHexString(RecipeConst.SETCODE_LEFT_OVERLAP_GRID),
			CommonUtil.LongToHexString(RecipeConst.SETCODE_XMB_POSITION_GRID),
			CommonUtil.LongToHexString(RecipeConst.SETCODE_PANEL_GROUP_GRID),
			CommonUtil.LongToHexString(lFreeLayoutPlateSetcode2ndXsmb),
			JobEditConst.SECOND_XSMB_USE,
		};

		for (int ii = 0; ii < FreeLayoutPlateSETCODE.values().length; ii++) {
			listSetCode.addAll(createData(FreeLayoutPlateSETCODE.values()[ii].getName(),
					iFreeLayoutPlateRows,
					FreeLayoutPlateSETCODE.values()[ii].getMargin()));
		}

		for (int ii = 0; ii < asFreeLayoutPlateCodeFormatGridId.length; ii++) {
			listSetCode.addAll(createData(asFreeLayoutPlateCodeFormatGridId[ii],
					aiFreeLayoutPlateRowsGrid[ii],
					lFreeLayoutPlateMarginGrid));
		}
		
		return listSetCode;
	}

	/**
	 * Creates BDC setcodes.
	 * 
	 * @return Setcode list
	 */
	private List<String> createBDCSetCodeList() {
		final List<String> listSetCode = new LinkedList<String>();
		
		for (int ii = 0; ii < RecipeConst.BDC_OFFSET_SET_CODE_NO.length; ii++) {
			listSetCode.addAll(createData(RecipeConst.BDC_OFFSET_SET_CODE_NO[ii],
					RecipeConst.BDC_OFFSET_ROWS,
					RecipeConst.BDC_OFFSET_MARGIN[ii]));
		}

		return listSetCode;
	}

	/**
	 * Creates SDC setcodes.
	 * 
	 * @return Setcode list
	 */
	private List<String> createSDCSetCodeList() {
		final List<String> listSetCode = new LinkedList<String>();
		
		for (int ii = 0; ii < RecipeConst.SDC_OFFSET_SET_CODE_NO.length; ii++) {
			listSetCode.addAll(createData(RecipeConst.SDC_OFFSET_SET_CODE_NO[ii],
					RecipeConst.SDC_OFFSET_ROWS,
					RecipeConst.SDC_OFFSET_MARGIN));
		}
		
		return listSetCode;
	}

	/**
	 * Creates Device setcodes.
	 * 
	 * @return Setcode list
	 */
	private List<String> createDeviceSetCodeList() {
		final List<String> listSetCode = new LinkedList<String>();

		listSetCode.add(RecipeConst.EXPOSUREMODE_NAME);
		listSetCode.add(RecipeConst.EXPOSUREMODE_NAME_SCAN);
		listSetCode.add(RecipeConst.EXPOSUREMODE_NAME_PERL);
		listSetCode.add(RecipeConst.SET_CODE_PLATE_SIZE_X);
		listSetCode.add(RecipeConst.SET_CODE_PLATE_SIZE_Y);
		listSetCode.add(RecipeConst.XSTEPNUM_NAME);
		listSetCode.add(RecipeConst.YSTEPNUM_NAME);
		listSetCode.add(RecipeConst.SET_CODE_EXPOSURE_SIZE_X);
		listSetCode.add(RecipeConst.SET_CODE_EXPOSURE_SIZE_Y);
		listSetCode.add(RecipeConst.SETCODE_MULTI_SHOT_FOCUS_DEVICE);
		listSetCode.add(RecipeConst.SETCODE_MULTI_SHOT_FOCUS_SHOT_PROCESS_NUM);
		listSetCode.add("3200C"); //SetCode for Masking Blade Waiting Position

		return listSetCode;
	}

	/**
	 * Performs out of range checking for DeviceData.
	 * 
	 * @return DeviceData error
	 */
	private Map<String, List<String>> performValueRangeCheck() {
		final Map<String, List<String>> mapDeviceDataError = new HashMap<String, List<String>>();
		final int iExpoMode = (int) m_mapConsData.get(JobEditConst.EXPO_MODE_SETCODE).getRealValue();

		if (JobEditConst.EXPO_MODE_PARTIAL == iExpoMode) {
			final List<String> listSetCodeCol = createPartialLayoutRowSetCodeList();
			mapDeviceDataError.putAll(checkIfOutOfRange(listSetCodeCol));

			if (mapDeviceDataError.size() != 0) {
				return mapDeviceDataError;
			}

			final List<String> listSetCodeRow = createPartialLayoutColumnSetCodeList();
			mapDeviceDataError.putAll(checkIfOutOfRange(listSetCodeRow));
			
			if (mapDeviceDataError.size() != 0) {
				return mapDeviceDataError;
			}
		} else if (JobEditConst.EXPO_MODE_FREE == iExpoMode) {
			final List<String> listSetCodeMask = createFreeMaskSetCodeList();
			mapDeviceDataError.putAll(checkIfOutOfRange(listSetCodeMask));
			
			if (mapDeviceDataError.size() != 0) {
				return mapDeviceDataError;
			}

			final List<String> listSetCodePlate = createFreePlateSetCodeList();
			mapDeviceDataError.putAll(checkIfOutOfRange(listSetCodePlate));

			if (mapDeviceDataError.size() != 0) {
				return mapDeviceDataError;
			}
		} else {
			final List<String> listDeviceSetCodeList = createDeviceSetCodeList();
			mapDeviceDataError.putAll(checkIfOutOfRange(listDeviceSetCodeList));

			if (mapDeviceDataError.size() != 0) {
				return mapDeviceDataError;
			}

			final List<String> listBDCSetCodeList = createBDCSetCodeList();
			mapDeviceDataError.putAll(checkIfOutOfRange(listBDCSetCodeList));

			if (mapDeviceDataError.size() != 0) {
				return mapDeviceDataError;
			}

			final List<String> listSDCSetCodeList = createSDCSetCodeList();
			mapDeviceDataError.putAll(checkIfOutOfRange(listSDCSetCodeList));

			if (mapDeviceDataError.size() != 0) {
				return mapDeviceDataError;
			}
		}

		return mapDeviceDataError;
	}
}
