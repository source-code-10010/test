[] adjustIllMultiTableForSave()
[] adjustMaskBendParticleInspectionTab()
[] adjustOASTab()
[] adjustPlateAATab()
[] adjustPlateAfcTab()
[] adjustProcessControlTab()
[] checkDuplicateSetCode()
[] checkMxCompModeChange()
[] checkOASBaseLineMeasurementShot(String, String, Map<String, AbstractConsoleData>, Map<String, AbstractConsoleData>)
[] checkOASJobExecute(Map<String, AbstractConsoleData>, Map<String, AbstractConsoleData>, String, String)
[] checkOASZeroLayerTabParameterError()
[] controlAFCProc()
[] controlAllShotAFCItem()
[] controlLastShotAFC()
[] controlOASFocusInterlock()
[] controlPlateFocusInterlock()
[] forceChangeBarmirrorMagnificationBase()
[] forceChangeForOASLayout()
[] forceChangeMeasurementParameter()
[] forceChangeOASBasePlateTVAACenterPosition()
[] forceChangeOASZSensorOffsetMeasurement()
[] forceValueForMaskLayoutVSCP()
[] forceValueForOpti50()
[] getADCMode()
[] getASFDC()
[] getCalcJobErrorSetCodeMap()
[] getConsDouble(String)
[] getConsLong(String)
[] getDeviceConsData(String)
[] getOffsetZeroSetCode(int)
[COVERED] getProcessConsData(String)
[] getStepNo()
[] getStepNum()
[] getXStepNum()
[] getYStepNum()
[] initialize()
[] isChangeOASLayout(Map<String, AbstractConsoleData>)
[] isChangeOASMeasurementSetting(Map<String, AbstractConsoleData>)
[] isEdgeModeAFCFast()
[] isOASEachShotAFCAveCompEnable()
[] isOASParanemic()
[] isOASZeroLayerMarkAlignmentOrAmfMeas()
[] isSmallAlignmentMark()
[] isTwoBendUse()
[] performValueRangeCheck()
[] prepareDataForValidation()
[] setConsDataValue(String, String)
[] setForceEdgeModeAFCFastOff()
[] updateDefocusMeasureInterval()
[] updateOASZMeasHomeSensorOffset()


public APIs:
ProcessDataRecipeValidator()           <------ COVERED
ProcessDataRecipeValidator(boolean)

[2] isChangeOASLayout(Map<String, AbstractConsoleData>)
[2] isChangeOASMeasurementSetting(Map<String, AbstractConsoleData>)
[2] isEdgeModeAFCFast()
[3: 1 Invalid; 2 Valid] performCheckValueWrong(long, boolean, boolean, Map<String, AbstractConsoleData>)
[2] performCalcJobForProcess(String, String, Map<String, AbstractConsoleData>, Map<String, AbstractConsoleData>)

[1: Invalid] validateProcessDataRecipe:checkDuplicateSetCode()


TODO:

1. Update implementation: ProcessDataRecipeValidator:performCheckValueWrong() --> same with DeviceDataRecipeValidator:performCheckValueWrong()
	* Commit to GUIRefactoring_5872 branch

2. In ProcessData/DeviceDataRecipeValidator, move convertAbstractConsoleDataToConsBase() to AbstractCommonRecipeValidator class
	* Commit to GUIRefactoring_5872 branch

3. TestCode: test_performCheckValueWrong_Valid_002 @ DeviceDataRecipeValidator, remove @throws RemoteException 




DeviceDataRecipeValidatorTest.test_getDataCheckErrorMessage_Valid_001()
DeviceDataRecipeValidatorTest.test_getDataCheckErrorMessage_Valid_002()
DeviceDataRecipeValidatorTest.test_getDataCheckErrorMessage_Valid_003()
DeviceDataRecipeValidatorTest.test_getDataCheckErrorMessage_Valid_004()
DeviceDataRecipeValidatorTest.test_getDataCheckErrorMessage_Valid_005()
DeviceDataRecipeValidatorTest.test_getDataCheckErrorMessage_Valid_006()
DeviceDataRecipeValidatorTest.test_getDataCheckErrorMessage_Valid_007()
DeviceDataRecipeValidatorTest.test_getDataCheckErrorMessage_Valid_008()
DeviceDataRecipeValidatorTest.test_getDataCheckErrorMessage_Valid_009()
DeviceDataRecipeValidatorTest.test_getDataCheckErrorMessage_Valid_010()
DeviceDataRecipeValidatorTest.test_getDataCheckErrorMessage_Invalid_001()
DeviceDataRecipeValidatorTest.test_getConsistencyCheck_Valid_001()
DeviceDataRecipeValidatorTest.test_performCheckValueWrong_Invalid()
DeviceDataRecipeValidatorTest.test_performCheckValueWrong_Valid_001()
DeviceDataRecipeValidatorTest.test_performCheckValueWrong_Valid_002()
DeviceDataRecipeValidatorTest.test_performCalcJobForDevice_Invalid()
DeviceDataRecipeValidatorTest.test_performCalcJobForDevice_Valid()
DeviceDataRecipeValidatorTest.test_validateDeviceDataRecipe_checkConsistency_Invalid_001()
DeviceDataRecipeValidatorTest.test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_001()
DeviceDataRecipeValidatorTest.test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_002()
DeviceDataRecipeValidatorTest.test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_003()
DeviceDataRecipeValidatorTest.test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_004()
DeviceDataRecipeValidatorTest.test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_005()
DeviceDataRecipeValidatorTest.test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_006()
DeviceDataRecipeValidatorTest.test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_007()
DeviceDataRecipeValidatorTest.test_validateDeviceDataRecipe_performCalcJobForDevice_Valid_001()


test_validateProcessDataRecipe_checkDuplicateSetCode_Invalid_001()
test_isChangeOASLayout_Valid_001()
test_isChangeOASLayout_Invalid_001()
test_isChangeOASMeasurementSetting_Valid_001()
test_isChangeOASMeasurementSetting_Invalid_001()
test_isEdgeModeAFCFast_Valid_001()
test_isEdgeModeAFCFast_Invalid_001()
test_performCheckValueWrong_Invalid()
test_performCheckValueWrong_Valid_001()
test_performCheckValueWrong_Valid_002()
test_performCalcJobForProcess_Invalid()
test_performCalcJobForProcess_Valid()
test_validateProcessDataRecipe_checkConsistency_Invalid_001()
test_validateProcessDataRecipe_performValueRangeCheck_Invalid_001()
test_validateProcessDataRecipe_performCalcJobForProcess_Valid_001()
test_validateProcessDataRecipe_checkOASJobExecute_invalid --> error(2) cannot test
test_validateProcessDataRecipe_checkOASJobExecute_invalid --> error(2) cannot test
test_validateProcessDataRecipe_isChangeOASLayout_invalid
test_validateProcessDataRecipe_isChangeOASMeasurementSetting_invalid
test_validateProcessDataRecipe_isChangeOASMeasurementSetting_Invalid_001
test_validateProcessDataRecipe_isChangeOASMeasurementSetting_Invalid_002
test_validateProcessDataRecipe_isChangeOASMeasurementSetting_Invalid_003
test_validateProcessDataRecipe_isChangeOASMeasurementSetting_Valid_001
test_validateProcessDataRecipe_performCheckValueWrong_Invalid_001
test_validateProcessDataRecipe_performCheckValueWrong_Invalid_002
test_validateProcessDataRecipe_performCheckValueWrong_Valid_001

* Ensure public apis called in UI performs well
