package canon.lcd.console.service.recipe.check;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import canon.lcd.console.consoleData.ConsBase;
import canon.lcd.console.consoleData.ConsoleDataUtils;
import canon.lcd.console.service.AbstractConsoleData;
import canon.lcd.console.service.recipe.JobEditConst;
import canon.lcd.console.service.recipe.RecipeConst;
import test.utility.ConsoleDataUtility;
import test.utility.ConsoleDataUtility.ConsoleDataType;

public class ProcessDataRecipeValidatorTest {

	/**
	 * Invalid Test Case:
	 * Setcodes "03000" and "03005" has duplicated data (2f082)
	 * Expected error message: <JobEditConst.ERROR_DUPLICATED_SETCODE>
	 */
	@Test
	public final void test_validateProcessDataRecipe_checkDuplicateSetCode_Invalid_001() {
		// Test Parameters and test data
		final String sDataFileNameDev = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/DupliErr.dev";
		final String sDataFileNamePro = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/DupliErr.pro";
		final String sMachineType = "H800";
		final String sDeviceName = "DupliErr.dev"; // placeholder only
		final String sProcessName = "DupliErr.pro"; // placeholder only

		// Expected result
		final Map<String, List<String>> mapExpected = new HashMap<String, List<String>>();
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add("03000");
		listErrorSetCode.add("03005");
		mapExpected.put(JobEditConst.ERROR_DUPLICATED_SETCODE, listErrorSetCode);

		// Load test data(Device)
		final Map<String, ConsBase> mapConsBaseDataDevice =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileNameDev,
						sMachineType);
		// Load test data(Process)
		final Map<String, ConsBase> mapConsBaseDataProcess =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Process, sDataFileNamePro,
						sMachineType);

		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsDataDevice =
				_convConsoleDataToAbstractConsoleData(mapConsBaseDataDevice);
		final Map<String, AbstractConsoleData> mapConsDataProcess =
				_convConsoleDataToAbstractConsoleData(mapConsBaseDataProcess);

		// Instantiate class under test: ProcessDataRecipeValidator
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();

		// Execute function under test: validateDeviceDataRecipe()
		final Map<String, List<String>> mapResult =
				validator.validateProcessDataRecipe(mapConsDataProcess, mapConsDataDevice, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult.get(JobEditConst.ERROR_DUPLICATED_SETCODE),
				is(equalTo(mapExpected.get(JobEditConst.ERROR_DUPLICATED_SETCODE))));
		assertThat(mapResult.get(JobEditConst.ERROR_DUPLICATED_SETCODE).size(),
				is(equalTo(mapExpected.get(JobEditConst.ERROR_DUPLICATED_SETCODE).size())));
	}
	
	/**
	 * Valid Test Case:
	 * OAS layout is not changed
	 * Expected result: false
	 */
	@Test
	public final void test_isChangeOASLayout_Valid_001() {
		// Test Parameters and Test Data
		final String sDataFileNameDev =
				"recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/OASLay.dev"; //TODO
		final String sDataFileNamePro =
				"recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/OASLay.pro"; //TODO
		final String sMachineType = "H800";

		// Expected result
		final boolean bExpected = false;
		
		// Load test data(Device)
		final Map<String, ConsBase> mapConsBaseDataProcess =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileNamePro,
						sMachineType);
		
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsDataProcess =
				_convConsoleDataToAbstractConsoleData(mapConsBaseDataProcess);

		// Execute function under test: validateDeviceDataRecipe()
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();
		
		// Execute function under test: isChangeOASLayout()
		final boolean bResult = validator.isChangeOASLayout(mapConsDataProcess);
		
		// Verification items
		assertThat(bResutlt, instanceOf(Boolean.class));
		assertThat(bResult, is(equalTo(bExpected)));
	}

	/**
	 * Invalid Test Case:
	 * OAS layout is changed
	 * Expected result: true
	 */
	@Test
	public final void test_isChangeOASLayout_Invalid_001() {

		// Test Parameters and Test Data
		final String sDataFileNameDev =
				"recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/OASLayErr.dev"; //TODO
		final String sDataFileNamePro =
				"recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/OASLayErr.pro"; //TODO
		final String sMachineType = "H800";

		// Expected result
		final boolean bExpected = true;
		
		// Load test data(Device)
		final Map<String, ConsBase> mapConsBaseDataProcess =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileNamePro,
						sMachineType);
		
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsDataProcess =
				_convConsoleDataToAbstractConsoleData(mapConsBaseDataProcess);

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();
		
		// Execute function under test
		final boolean bResult = validator.isChangeOASLayout(mapConsDataProcess);
		
		// Verification items
		assertThat(bResutlt, instanceOf(Boolean.class));
		assertThat(bResult, is(equalTo(bExpected)));
	}

	/**
	 * Valid Test Case:
	 * OAS Measurement Setting is not changed
	 * Expected result: false
	 */
	@Test
	public final void test_isChangeOASMeasurementSetting_Valid_001() {
		// Test Parameters and Test Data
		final String sDataFileNameDev =
				"recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/OASMeas.dev"; //TODO
		final String sDataFileNamePro =
				"recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/OASMeas.pro"; //TODO
		final String sMachineType = "H800";

		// Expected result
		final boolean bExpected = false;
		
		// Load test data(Device)
		final Map<String, ConsBase> mapConsBaseDataProcess =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileNamePro,
						sMachineType);
		
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsDataProcess =
				_convConsoleDataToAbstractConsoleData(mapConsBaseDataProcess);

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();
		
		// Execute function under test
		final boolean bResult = validator.isChangeOASMeasurementSetting(mapConsDataProcess);
		
		// Verification items
		assertThat(bResutlt, instanceOf(Boolean.class));
		assertThat(bResult, is(equalTo(bExpected)));
	}

	/**
	 * Invalid Test Case:
	 * OAS Measurement Setting is changed
	 * Expected result: true
	 */
	@Test
	public final void test_isChangeOASMeasurementSetting_Invalid_001() {

		// Test Parameters and Test Data
		final String sDataFileNameDev =
				"recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/OASMeasErr.dev"; //TODO
		final String sDataFileNamePro =
				"recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/OASMeasErr.pro"; //TODO
		final String sMachineType = "H800";

		// Expected result
		final boolean bExpected = true;
		
		// Load test data(Device)
		final Map<String, ConsBase> mapConsBaseDataProcess =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileNamePro,
						sMachineType);
		
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsDataProcess =
				_convConsoleDataToAbstractConsoleData(mapConsBaseDataProcess);

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();
		
		// Execute function under test
		final boolean bResult = validator.isChangeOASMeasurementSetting(mapConsDataProcess);
		
		// Verification items
		assertThat(bResutlt, instanceOf(Boolean.class));
		assertThat(bResult, is(equalTo(bExpected)));
	}


	/**
	 * Valid Test Case:
	 * Edge Mode AFC Fast is enabled
	 * Expected result: true
	 */
	@Test
	public final void test_isEdgeModeAFCFast_Valid_001() {
		new MockUp<FunctionCheckerControl>() { //TODO

			private String[] m_sCheckerName = {"EdgeModeAFCFastChecker"};

			@Mock
			public boolean isFunctionEnabled(final String sName) {
				boolean isValid = false;
				for (String sCheckerName : m_sCheckerName) {
					if (sName.contains(sCheckerName)) {
						isValid = true;
					}
				}
				return isValid;
			}
		};

		// Expected result
		final boolean bExpected = true;

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();
		
		// Execute function under test
		final boolean bResult = validator.isEdgeModeAFCFast();
		
		// Verification items
		assertThat(bResutlt, instanceOf(Boolean.class));
		assertThat(bResult, is(equalTo(bExpected)));
	}

	/**
	 * Invalid Test Case:
	 * Edge Mode AFC Fast is not enabled
	 * Expected result: false
	 */
	@Test
	public final void test_isEdgeModeAFCFast_Invalid_001() {
		new MockUp<FunctionCheckerControl>() { //TODO

			private String[] m_sCheckerName = {""};

			@Mock
			public boolean isFunctionEnabled(final String sName) {
				boolean isValid = false;
				for (String sCheckerName : m_sCheckerName) {
					if (sName.contains(sCheckerName)) {
						isValid = true;
					}
				}
				return isValid;
			}
		};

		// Expected result
		final boolean bExpected = false;

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();
		
		// Execute function under test
		final boolean bResult = validator.isEdgeModeAFCFast();
		
		// Verification items
		assertThat(bResutlt, instanceOf(Boolean.class));
		assertThat(bResult, is(equalTo(bExpected)));
	}
	

	/**
	 * Invalid Test Case:
	 * TODO
	 * Expected result is TODO
	 */
	@Test
	public final void test_performCheckValueWrong_Invalid() {
		new MockUp<FunctionCheckerControl>() {

			private String[] m_sCheckerName = {"SlitMaskingBladeChecker"};

			@Mock
			public boolean isFunctionEnabled(final String sName) {
				boolean isValid = false;
				for (String sCheckerName : m_sCheckerName) {
					if (sName.contains(sCheckerName)) {
						isValid = true;
					}
				}
				return isValid;
			}
		};

		// Test Parameters and test data
		final int iExposureMode = JobEditConst.EXPO_MODE_FREE;
		final boolean bEnabledXSMB = false;
		final boolean bEnabledYSMB = true;
		final String sProcessFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/Error1.pro"; //TODO
		final String sMachineType = "H800";

		// Expected result
		final int iErrorShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_FRONT_OVERLAP_LIMIT; //TODO
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add(CommonUtil.LongToHexString(RecipeConst.SETCODE_FRONT_OVERLAP_STEP)); //TODO
		final ValueWrongCheckProxy expectedResult = new ValueWrongCheckProxy(iErrorShotNo, iErrorNo, listErrorSetCode);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.PROCESS, sProcessFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();

		// Execute function under test
		final ValueWrongCheckProxy result =
				validator.performCheckValueWrong(iExposureMode, bEnabledXSMB, bEnabledYSMB, mapConsData);

		// Verification items
		assertThat(result, instanceOf(ValueWrongCheckProxy.class));
		assertThat(result.getShotNo(), is(equalTo(expectedResult.getShotNo())));
		assertThat(result.getErrorNo(), is(equalTo(expectedResult.getErrorNo())));
		assertThat(result.getErrorSetCodeList(), is(equalTo(expectedResult.getErrorSetCodeList())));
		assertThat(result.getErrorSetCodeList().size(), is(equalTo(expectedResult.getErrorSetCodeList().size())));
	}

	/**
	 * Valid Test Case:
	 * Exposure mode is not FreeLayout
	 * Expected result is VALUE_CHECK_OK
	 */
	@Test
	public final void test_performCheckValueWrong_Valid_001() {
		// Test Parameters and test data
		final int iExposureMode = JobEditConst.EXPO_MODE_PARTIAL;
		final boolean bEnabledXSMB = false;
		final boolean bEnabledYSMB = true;
		final String sProcessFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/ValidPro.pro"; //TODO
		final String sMachineType = "H800";

		// Expected result
		final ValueWrongCheckProxy expectedResult = new ValueWrongCheckProxy(RecipeConst.VALUE_CHECK_OK);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.PROCESS, sProcessFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();

		// Execute function under test
		final ValueWrongCheckProxy result = 
				validator.performCheckValueWrong(iExposureMode, bEnabledXSMB, bEnabledYSMB, mapConsData);

		// Verification items
		assertThat(result, instanceOf(ValueWrongCheckProxy.class));
		assertThat(result.getShotNo(), is(equalTo(expectedResult.getShotNo())));
		assertThat(result.getErrorNo(), is(equalTo(expectedResult.getErrorNo())));
		assertThat(result.getErrorSetCodeList().size(), is(equalTo(expectedResult.getErrorSetCodeList().size())));
	}

	/**
	 * Valid Test Case:
	 * No value wrong check errors
	 * Expected result is VALUE_CHECK_OK
	 */
	@Test
	public final void test_performCheckValueWrong_Valid_002() {
		new MockUp<FunctionCheckerControl>() {

			private String[] m_sCheckerName = {"XSlitMaskingBladeChecker", "SlitMaskingBladeChecker"};

			@Mock
			public boolean isFunctionEnabled(final String sName) {
				boolean isValid = false;
				for (String sCheckerName : m_sCheckerName) {
					if (sName.equals(sCheckerName)) {
						isValid = true;
					}
				}
				return isValid;
			}
		};

		// Test Parameters and test data
		final int iExposureMode = JobEditConst.EXPO_MODE_FREE;
		final boolean bEnabledXSMB = false;
		final boolean bEnabledYSMB = true;
		final String sProcessFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/ValidPro.pro"; //TODO
		final String sMachineType = "H800";

		// Expected result
		final ValueWrongCheckProxy expectedResult = new ValueWrongCheckProxy(RecipeConst.VALUE_CHECK_OK);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.PROCESS, sProcessFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test
		final ValueWrongCheckProxy result = 
				validator.performCheckValueWrong(iExposureMode, bEnabledXSMB, bEnabledYSMB, mapConsData);

		// Verification items
		assertThat(result, instanceOf(ValueWrongCheckProxy.class));
		assertThat(result.getShotNo(), is(equalTo(expectedResult.getShotNo())));
		assertThat(result.getErrorNo(), is(equalTo(expectedResult.getErrorNo())));
		assertThat(result.getErrorSetCodeList().size(), is(equalTo(expectedResult.getErrorSetCodeList().size())));
	}


	/**
	 * Invalid Test Case:
	 * Step Num X (02010) is set to 10 (Valid is <= 5) //TODO
	 * Step Num Y (02011) is set to 4 (Valid is <= 3)  //TODO
	 * Expected result is Empty HashMap				   //TODO
	 */
	@Test
	public final void test_performCalcJobForProcess_Invalid() {
		// Test Parameters and test data
		final String sDeviceName = "TST004"; // data/console/job directory TODO
		final String sProcessName = "TST004"; // data/console/job directory TODO
		final String sDeviceFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/TST004ER.dev"; //TODO
		final String sProcessFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/TST004ER.pro"; //TODO
		final String sMachineType = "H800";

		// Expected results
		final Map<String, AbstractConsoleData> mapExpected = new HashMap<String, AbstractConsoleData>(); //TODO
		
		// Load test data
		final Map<String, ConsBase> mapConsBaseDevice =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.DEVICE, sDeviceFileName, sMachineType);
		final Map<String, ConsBase> mapConsBaseProcess =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.PROCESS, sProcessFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsDataDevice = _convConsoleDataToAbstractConsoleData(mapConsBaseDevice);
		final Map<String, AbstractConsoleData> mapConsDataProcess = _convConsoleDataToAbstractConsoleData(mapConsBaseProcess);

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();

		// Execute function under test
		final Map<String, AbstractConsoleData> mapResult = validator.performCalcJobForProcess(sDeviceName, sProcessName, mapConsDataProcess, mapConsDataDevice);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult, is(equalTo(mapExpected)));
	}

	/**
	 * Valid Test Case:
	 * Step Num X (02010) is set to 4 (Valid is <= 5) //TODO
	 * Step Num Y (02011) is set to 2 (Valid is <= 3) //TODO
	 * Expected result is HashMap contains valid data //TODO
	 */
	@Test
	public final void test_performCalcJobForProcess_Valid() {
		// Test Parameters and test data
		final String sDeviceName = "TST004"; // data/console/job directory TODO
		final String sProcessName = "TST004"; // data/console/job directory TODO
		final String sDeviceFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/TST004ER.dev"; //TODO
		final String sProcessFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/TST004ER.pro"; //TODO
		final String sMachineType = "H800";

		// Load test data
		final Map<String, ConsBase> mapConsBaseDevice =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.DEVICE, sDeviceFileName, sMachineType);
		final Map<String, ConsBase> mapConsBaseProcess =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.PROCESS, sProcessFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsDataDevice = _convConsoleDataToAbstractConsoleData(mapConsBaseDevice);
		final Map<String, AbstractConsoleData> mapConsDataProcess = _convConsoleDataToAbstractConsoleData(mapConsBaseProcess);

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();

		// Execute function under test
		final Map<String, AbstractConsoleData> mapResult = validator.performCalcJobForProcess(sDeviceName, sProcessName, mapConsDataProcess, mapConsDataDevice);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapConsDataProcess.size())));
		assertThat(mapResult, is(equalTo(mapConsDataProcess)));
	}

//	
//	
//	ADD FOR validateProcessDataRecipe:prepareDataForValidation()
//	
//	
	
	/**
	 * Machine Type: H800
	 * 
	 * Invalid Test Case:
	 * Exposure Area Left (020C1): 375 < Exposure Area Right (020C4): 400 TODO
	 * Expected error message: TODO
	 * Expected error setcodes: TODO
	 */
	@Test
	public final void test_validateProcessDataRecipe_checkConsistency_Invalid_001() {
		// Test Parameters and test data
		final String sDeviceName = "Error1"; // placeholder ONLY //TODO
		final String sProcessName = "Error1"; // placeholder ONLY //TODO
		final String sDeviceFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/Error1.dev"; //TODO
		final String sProcessFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/Error1.pro"; //TODO
		final String sMachineType = "H800";

		// Expected result
		final Map<String, List<String>> mapExpected = new HashMap<String, List<String>>();
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add(JobEditConst.MASK_PATTERN_A_DEV[1]); //TODO
		listErrorSetCode.add(JobEditConst.MASK_PATTERN_A_DEV[4]); //TODO
		mapExpected.put(JobEditConst.ERROR_EXPO_AREA, listErrorSetCode); //TODO
		
		// Load test data
		final Map<String, ConsBase> mapConsBaseDevice =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.DEVICE, sDeviceFileName, sMachineType);
		final Map<String, ConsBase> mapConsBaseProcess =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.PROCESS, sProcessFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsDataDevice = _convConsoleDataToAbstractConsoleData(mapConsBaseDevice);
		final Map<String, AbstractConsoleData> mapConsDataProcess = _convConsoleDataToAbstractConsoleData(mapConsBaseProcess);

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();

		// Execute function under test
		final Map<String, List<String>> mapResult =
				validator.validateProcessDataRecipe(mapConsDataProcess, mapConsDataDevice, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult.get(JobEditConst.ERROR_EXPO_AREA),
				is(equalTo(mapExpected.get(JobEditConst.ERROR_EXPO_AREA)))); //TODO
		assertThat(mapResult.get(JobEditConst.ERROR_EXPO_AREA).size(),
				is(equalTo(mapExpected.get(JobEditConst.ERROR_EXPO_AREA).size()))); //TODO
	}


	/**
	 * Exposure Mode: Partial
	 * Machine Type: H800
	 * 
	 * Partial Layout:
	 *  Row Alignment Position[01](02330) is set to 5 (Max: 2) TODO
	 * 
	 * Test data: range001.dev TODO
	 * 
	 * Expected error: "Please Check Value."
	 * Expected error setcodes: 02330 TODO
	 */
	@Test
	public final void test_validateProcessDataRecipe_performValueRangeCheck_Invalid_001() {
		new MockUp<ConsistencyCheckForProcess>() {
			@Mock
			public List<String> checkConsistency(final int iItemIndex,
					final Map<String, AbstractConsoleData> mapConsData) {
				final List<String> dummyList = new LinkedList<String>();
				return dummyList;
			}
			@Mock
			public Map<String, List<String>> getErrorSetCodeMap() {
				Map<String, List<String>> mapErrorMessage = new HashMap<String, List<String>>();
				return mapErrorMessage;
			}
		};
		// Test Parameters and test data
		final String sDeviceName = "range001"; // placeholder ONLY //TODO
		final String sProcessName = "range001"; // placeholder ONLY //TODO
		final String sDeviceFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/range001.dev"; //TODO
		final String sProcessFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/range001.pro"; //TODO
		final String sMachineType = "H800";

		// Expected result
		final Map<String, List<String>> mapExpected = new HashMap<String, List<String>>();
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add(JobEditConst.ALIGNMENTPOS_ALLAY[0]); //TODO
		mapExpected.put(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE, listErrorSetCode);

		// Load test data
		final Map<String, ConsBase> mapConsBaseDevice =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.DEVICE, sDeviceFileName, sMachineType);
		final Map<String, ConsBase> mapConsBaseProcess =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.PROCESS, sProcessFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsDataDevice = _convConsoleDataToAbstractConsoleData(mapConsBaseDevice);
		final Map<String, AbstractConsoleData> mapConsDataProcess = _convConsoleDataToAbstractConsoleData(mapConsBaseProcess);

		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();

		// Execute function under test
		final Map<String, List<String>> mapResult =
				validator.validateProcessDataRecipe(mapConsDataProcess, mapConsDataDevice, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE))));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size(),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size())));
	}
	

	/**
	 * Valid Test Case:
	 * Step Num X (02010) is set to 4 (Valid is <= 5) //TODO
	 * Step Num Y (02011) is set to 2 (Valid is <= 3) //TODO
	 * Expected result is HashMap contains valid data
	 */
	@Test
	public final void test_validateProcessDataRecipe_performCalcJobForProcess_Valid_001() {
		new MockUp<ConsistencyCheckForProcess>() {
			@Mock
			public List<String> checkConsistency(final int iItemIndex,
					final Map<String, AbstractConsoleData> mapConsData) {
				final List<String> dummyList = new LinkedList<String>();
				return dummyList;
			}
			@Mock
			public Map<String, List<String>> getErrorSetCodeMap() {
				Map<String, List<String>> mapErrorMessage = new HashMap<String, List<String>>();
				return mapErrorMessage;
			}
		};
		// Test Parameters and test data
		final String sDeviceName = "calcjob1"; // data/console/job directory TODO
		final String sProcessName = "calcjob1"; // data/console/job directory TODO
		final String sDeviceFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/" + sDeviceName; //TODO
		final String sProcessFileName = "recipe_consistency_check_testdata/ProcessDataRecipeValidatorTestData/" + sProcessName; //TODO
		final String sMachineType = "H800";

		final Map<String, ConsBase> mapConsBaseDevice =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.DEVICE, sDeviceFileName, sMachineType);
		final Map<String, ConsBase> mapConsBaseProcess =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.PROCESS, sProcessFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsDataDevice = _convConsoleDataToAbstractConsoleData(mapConsBaseDevice);
		final Map<String, AbstractConsoleData> mapConsDataProcess = _convConsoleDataToAbstractConsoleData(mapConsBaseProcess);
		
		// Instantiate class under test
		final ProcessDataRecipeValidator validator = new ProcessDataRecipeValidator();

		// Execute function under test
		final Map<String, List<String>> mapResult =
				validator.validateProcessDataRecipe(mapConsDataProcess, mapConsDataDevice, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapConsDataProcess.size())));
		assertThat(mapResult, is(equalTo(mapExpected)));
	}
	
	/**
	 * ConsBase‚ðAbstractConsoleData‚É•ÏŠ·�B
	 *
	 * @param mapConsData ConsBaseƒ}ƒbƒv
	 * @return AbstractConsoleDataƒ}ƒbƒv
	 */
	private Map<String, AbstractConsoleData> _convConsoleDataToAbstractConsoleData(
			final Map<String, ConsBase> mapConsData) {
		final Map<String, AbstractConsoleData> mapAbstractConsoleData = new HashMap<String, AbstractConsoleData>();

		for (final ConsBase consBase : mapConsData.values()) {
			mapAbstractConsoleData.put(consBase.getName(), ConsoleDataUtils.getConsoleData(consBase));
		}

		return mapAbstractConsoleData;
	}
}
