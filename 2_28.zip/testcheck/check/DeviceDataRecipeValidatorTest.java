package canon.lcd.console.service.recipe.check;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.experimental.theories.Theories;
import org.junit.runner.RunWith;

import mockit.Mock;
import mockit.MockUp;

import canon.lcd.console.consoleData.ConsBase;
import canon.lcd.console.consoleData.ConsoleDataUtils;
import canon.lcd.console.service.AbstractConsoleData;
import canon.lcd.console.service.funcchecker.impl.FunctionCheckerControl;
import canon.lcd.console.service.recipe.JobEditConst;
import canon.lcd.console.service.recipe.RecipeConst;
import canon.lcd.console.service.recipe.ValueWrongCheckProxy;
import canon.lcd.console.utility.CommonUtil;
import test.utility.ConsoleDataUtility;
import test.utility.ConsoleDataUtility.ConsoleDataType;

public class DeviceDataRecipeValidatorTest {

	/**
	 * Valid Test Case:
	 * ValueWrongCheck Error No: -304
	 * Expected error message:"Please Check Value.\r\nStep(1) XSMB Position Error."
	 */
	@Test
	public final void test_getDataCheckErrorMessage_Valid_001() {
		// Test Parameters and test data
		final int iShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_XSMB_POSITION;
		final ValueWrongCheckProxy testData = new ValueWrongCheckProxy(iShotNo, iErrorNo);

		// Expected result
		final String sExpectedErrorMessage = "Please Check Value.\r\n" + 
				"Step(1) XSMB Position Error.";

		// Execute function under test: getDataCheckErrorMessage()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final String sErrorMessage = validator.getDataCheckErrorMessage(testData);

		// Verification items
		assertThat(sErrorMessage, instanceOf(String.class));
		assertThat(sErrorMessage, is(equalTo(sExpectedErrorMessage)));
		assertThat(sErrorMessage.length(), is(equalTo(sExpectedErrorMessage.length())));
	}

	/**
	 * Valid Test Case:
	 * ValueWrongCheck Error No: -305
	 * Expected error message:"Please Check Value.\r\nStep(1) YSMB Side Unmatch Expo Direction."
	 */
	@Test
	public final void test_getDataCheckErrorMessage_Valid_002() {
		// Test Parameters and test data
		final int iShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_YSMB_DIRECTION;
		final ValueWrongCheckProxy testData = new ValueWrongCheckProxy(iShotNo, iErrorNo);

		// Expected result
		final String sExpectedErrorMessage = "Please Check Value.\r\n" + 
				"Step(1) YSMB Side Unmatch Expo Direction.";

		// Execute function under test: getDataCheckErrorMessage()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final String sErrorMessage = validator.getDataCheckErrorMessage(testData);

		// Verification items
		assertThat(sErrorMessage, instanceOf(String.class));
		assertThat(sErrorMessage, is(equalTo(sExpectedErrorMessage)));
		assertThat(sErrorMessage.length(), is(equalTo(sExpectedErrorMessage.length())));
	}

	/**
	 * Valid Test Case:
	 * ValueWrongCheck Error No: -307
	 * Expected error message:"Please Check Value.\r\nStep(1) Front Overlap Duplicate."
	 */
	@Test
	public final void test_getDataCheckErrorMessage_Valid_003() {
		// Test Parameters and test data
		final int iShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_FRONT_OVERLAP_DUPLICATE;
		final ValueWrongCheckProxy testData = new ValueWrongCheckProxy(iShotNo, iErrorNo);

		// Expected result
		final String sExpectedErrorMessage = "Please Check Value.\r\n" + 
				"Step(1) Front Overlap Duplicate.";

		// Execute function under test: getDataCheckErrorMessage()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final String sErrorMessage = validator.getDataCheckErrorMessage(testData);

		// Verification items
		assertThat(sErrorMessage, instanceOf(String.class));
		assertThat(sErrorMessage, is(equalTo(sExpectedErrorMessage)));
		assertThat(sErrorMessage.length(), is(equalTo(sExpectedErrorMessage.length())));
	}

	/**
	 * Valid Test Case:
	 * ValueWrongCheck Error No: -306
	 * Expected error message:"Please Check Value.\r\nStep(1) Front Overlap Limit Error."
	 */
	@Test
	public final void test_getDataCheckErrorMessage_Valid_004() {
		// Test Parameters and test data
		final int iShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_FRONT_OVERLAP_LIMIT;
		final ValueWrongCheckProxy testData = new ValueWrongCheckProxy(iShotNo, iErrorNo);

		// Expected result
		final String sExpectedErrorMessage = "Please Check Value.\r\n" + 
				"Step(1) Front Overlap Limit Error.";

		// Execute function under test: getDataCheckErrorMessage()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final String sErrorMessage = validator.getDataCheckErrorMessage(testData);

		// Verification items
		assertThat(sErrorMessage, instanceOf(String.class));
		assertThat(sErrorMessage, is(equalTo(sExpectedErrorMessage)));
		assertThat(sErrorMessage.length(), is(equalTo(sExpectedErrorMessage.length())));
	}

	/**
	 * Valid Test Case:
	 * ValueWrongCheck Error No: -309
	 * Expected error message:"Please Check Value.\r\nStep(1) Left Overlap Duplicate."
	 */
	@Test
	public final void test_getDataCheckErrorMessage_Valid_005() {
		// Test Parameters and test data
		final int iShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_LEFT_OVERLAP_DUPLICATE;
		final ValueWrongCheckProxy testData = new ValueWrongCheckProxy(iShotNo, iErrorNo);

		// Expected result
		final String sExpectedErrorMessage = "Please Check Value.\r\n" + 
				"Step(1) Left Overlap Duplicate.";

		// Execute function under test: getDataCheckErrorMessage()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final String sErrorMessage = validator.getDataCheckErrorMessage(testData);

		// Verification items
		assertThat(sErrorMessage, instanceOf(String.class));
		assertThat(sErrorMessage, is(equalTo(sExpectedErrorMessage)));
		assertThat(sErrorMessage.length(), is(equalTo(sExpectedErrorMessage.length())));
	}

	/**
	 * Valid Test Case:
	 * ValueWrongCheck Error No: -308
	 * Expected error message:"Please Check Value.\r\nStep(1) Left Overlap Limit Error."
	 */
	@Test
	public final void test_getDataCheckErrorMessage_Valid_006() {
		// Test Parameters and test data
		final int iShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_LEFT_OVERLAP_LIMIT;
		final ValueWrongCheckProxy testData = new ValueWrongCheckProxy(iShotNo, iErrorNo);

		// Expected result
		final String sExpectedErrorMessage = "Please Check Value.\r\n" + 
				"Step(1) Left Overlap Limit Error.";

		// Execute function under test: getDataCheckErrorMessage()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final String sErrorMessage = validator.getDataCheckErrorMessage(testData);

		// Verification items
		assertThat(sErrorMessage, instanceOf(String.class));
		assertThat(sErrorMessage, is(equalTo(sExpectedErrorMessage)));
		assertThat(sErrorMessage.length(), is(equalTo(sExpectedErrorMessage.length())));
	}

	/**
	 * Valid Test Case:
	 * ValueWrongCheck Error No: -310
	 * Expected error message:"Please Check Value.\r\nStep(1) YSMB Side Unmatch."
	 */
	@Test
	public final void test_getDataCheckErrorMessage_Valid_007() {
		// Test Parameters and test data
		final int iShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_YSMB_SIDE;
		final ValueWrongCheckProxy testData = new ValueWrongCheckProxy(iShotNo, iErrorNo);

		// Expected result
		final String sExpectedErrorMessage = "Please Check Value.\r\n" + 
				"Step(1) YSMB Side Unmatch.";

		// Execute function under test: getDataCheckErrorMessage()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final String sErrorMessage = validator.getDataCheckErrorMessage(testData);

		// Verification items
		assertThat(sErrorMessage, instanceOf(String.class));
		assertThat(sErrorMessage, is(equalTo(sExpectedErrorMessage)));
		assertThat(sErrorMessage.length(), is(equalTo(sExpectedErrorMessage.length())));
	}

	/**
	 * Valid Test Case:
	 * ValueWrongCheck Error No: -311
	 * Expected error message:"Please Check Value.\r\nStep(1) XSMB Side Unmatch."
	 */
	@Test
	public final void test_getDataCheckErrorMessage_Valid_008() {
		// Test Parameters and test data
		final int iShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_XSMB_SIDE;
		final ValueWrongCheckProxy testData = new ValueWrongCheckProxy(iShotNo, iErrorNo);

		// Expected result
		final String sExpectedErrorMessage = "Please Check Value.\r\n" + 
				"Step(1) XSMB Side Unmatch.";

		// Execute function under test: getDataCheckErrorMessage()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final String sErrorMessage = validator.getDataCheckErrorMessage(testData);

		// Verification items
		assertThat(sErrorMessage, instanceOf(String.class));
		assertThat(sErrorMessage, is(equalTo(sExpectedErrorMessage)));
		assertThat(sErrorMessage.length(), is(equalTo(sExpectedErrorMessage.length())));
	}

	/**
	 * Valid Test Case:
	 * ValueWrongCheck Error No: -313
	 * Expected error message:"Please Check Value.\r\nStep(1) <html>Magnification Comp. Mode can�ft change to lower 
	 * value.<br>Please clear Feedback Offset value.</html>"
	 */
	@Test
	public final void test_getDataCheckErrorMessage_Valid_009() {
		// Test Parameters and test data
		final int iShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_MX_COMP_CHANGE;
		final ValueWrongCheckProxy testData = new ValueWrongCheckProxy(iShotNo, iErrorNo);

		// Expected result
		final String sExpectedErrorMessage = "Please Check Value.\r\n" + 
			"<html>Magnification Comp. Mode can�ft change to lower value.<br>Please clear Feedback Offset value.</html>";

		// Execute function under test: getDataCheckErrorMessage()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final String sErrorMessage = validator.getDataCheckErrorMessage(testData);

		// Verification items
		assertThat(sErrorMessage, instanceOf(String.class));
		assertThat(sErrorMessage, is(equalTo(sExpectedErrorMessage)));
		assertThat(sErrorMessage.length(), is(equalTo(sExpectedErrorMessage.length())));
	}

	/**
	 * Valid Test Case:
	 * ValueWrongCheck Error No: -316
	 * Expected error message:"Please Check Value.\r\nStep(1) 2nd XSMB Use Unmatch."
	 */
	@Test
	public final void test_getDataCheckErrorMessage_Valid_010() {
		// Test Parameters and test data
		final int iShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_2ND_XSMB_USE;
		final ValueWrongCheckProxy testData = new ValueWrongCheckProxy(iShotNo, iErrorNo);

		// Expected result
		final String sExpectedErrorMessage = "Please Check Value.\r\n" + 
				"Step(1) 2nd XSMB Use Unmatch.";

		// Execute function under test: getDataCheckErrorMessage()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final String sErrorMessage = validator.getDataCheckErrorMessage(testData);

		// Verification items
		assertThat(sErrorMessage, instanceOf(String.class));
		assertThat(sErrorMessage, is(equalTo(sExpectedErrorMessage)));
		assertThat(sErrorMessage.length(), is(equalTo(sExpectedErrorMessage.length())));
	}

	/**
	 * Invalid Test Case:
	 * ValueWrongCheck Error No: -100 (Error no is invalid)
	 * Expected error message:"Please Check Value.\r\n"
	 */
	@Test
	public final void test_getDataCheckErrorMessage_Invalid_001() {
		// Test Parameters and test data
		final int iShotNo = 1;
		final int iErrorNo = -100;
		final ValueWrongCheckProxy testData = new ValueWrongCheckProxy(iShotNo, iErrorNo);

		// Expected result
		final String sExpectedErrorMessage = "Please Check Value.\r\n";

		// Execute function under test: getDataCheckErrorMessage()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final String sErrorMessage = validator.getDataCheckErrorMessage(testData);

		// Verification items
		assertThat(sErrorMessage, instanceOf(String.class));
		assertThat(sErrorMessage, is(equalTo(sExpectedErrorMessage)));
		assertThat(sErrorMessage.length(), is(equalTo(sExpectedErrorMessage.length())));
	}

	/**
	 * Valid Test Case:
	 * ValueWrongCheck Error No: -100 (Error no is invalid)
	 * Expected error message:"Please Check Value.\r\n"
	 */
	@Test
	public final void test_getConsistencyCheck_Valid_001() {
		// Execute function under test: <set/get>ConsistencyCheck()
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();
		final ConsistencyCheckIF consistencyCheckInstance = validator.getConsistencyCheck();

		// Verification items
		assertThat(consistencyCheckInstance, instanceOf(ConsistencyCheckForDevice.class));
	}

	/**
	 * Invalid Test Case:
	 * SETCODE_FRONT_OVERLAP_STEP (02730) is set to 5 which is greater than ALL STEP NUM (12000) which has 1 as value
	 * Expected result is VALUE_ERROR_FRONT_OVERLAP_LIMIT
	 */
	@Test
	public final void test_performCheckValueWrong_Invalid() {
		new MockUp<FunctionCheckerControl>() {

			private String[] m_sCheckerName = {"SlitMaskingBladeChecker"};

			@Mock
			public boolean isFunctionEnabled(final String sName) {
				boolean isValid = false;
				for (String sCheckerName : m_sCheckerName) {
					if (sName.contains(sCheckerName)) {
						isValid = true;
					}
				}
				return isValid;
			}
		};

		// Test Parameters and test data
		final int iExposureMode = JobEditConst.EXPO_MODE_FREE;
		final boolean bEnabledXSMB = false;
		final boolean bEnabledYSMB = true;
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/Error1.dev";
		final String sMachineType = "H800";

		// Expected result
		final int iErrorShotNo = 1;
		final int iErrorNo = RecipeConst.VALUE_ERROR_FRONT_OVERLAP_LIMIT;
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add(CommonUtil.LongToHexString(RecipeConst.SETCODE_FRONT_OVERLAP_STEP));
		final ValueWrongCheckProxy expectedResult = new ValueWrongCheckProxy(iErrorShotNo, iErrorNo, listErrorSetCode);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: performCheckValueWrong()
		final ValueWrongCheckProxy result =
				validator.performCheckValueWrong(iExposureMode, bEnabledXSMB, bEnabledYSMB, mapConsData);

		// Verification items
		assertThat(result, instanceOf(ValueWrongCheckProxy.class));
		assertThat(result.getShotNo(), is(equalTo(expectedResult.getShotNo())));
		assertThat(result.getErrorNo(), is(equalTo(expectedResult.getErrorNo())));
		assertThat(result.getErrorSetCodeList(), is(equalTo(expectedResult.getErrorSetCodeList())));
		assertThat(result.getErrorSetCodeList().size(), is(equalTo(expectedResult.getErrorSetCodeList().size())));
	}

	/**
	 * Valid Test Case:
	 * Exposure mode is not FreeLayout
	 * Expected result is VALUE_CHECK_OK
	 */
	@Test
	public final void test_performCheckValueWrong_Valid_001() {
		// Test Parameters and test data
		final int iExposureMode = JobEditConst.EXPO_MODE_PARTIAL;
		final boolean bEnabledXSMB = false;
		final boolean bEnabledYSMB = true;
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/ValidDev.dev";
		final String sMachineType = "H800";

		// Expected result
		final ValueWrongCheckProxy expectedResult = new ValueWrongCheckProxy(RecipeConst.VALUE_CHECK_OK);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: performCheckValueWrong()
		final ValueWrongCheckProxy result = 
				validator.performCheckValueWrong(iExposureMode, bEnabledXSMB, bEnabledYSMB, mapConsData);

		// Verification items
		assertThat(result, instanceOf(ValueWrongCheckProxy.class));
		assertThat(result.getShotNo(), is(equalTo(expectedResult.getShotNo())));
		assertThat(result.getErrorNo(), is(equalTo(expectedResult.getErrorNo())));
		assertThat(result.getErrorSetCodeList().size(), is(equalTo(expectedResult.getErrorSetCodeList().size())));
	}

	/**
	 * Valid Test Case:
	 * No value wrong check errors
	 * Expected result is VALUE_CHECK_OK
	 */
	@Test
	public final void test_performCheckValueWrong_Valid_002() {
		new MockUp<FunctionCheckerControl>() {

			private String[] m_sCheckerName = {"XSlitMaskingBladeChecker", "SlitMaskingBladeChecker"};

			@Mock
			public boolean isFunctionEnabled(final String sName) {
				boolean isValid = false;
				for (String sCheckerName : m_sCheckerName) {
					if (sName.equals(sCheckerName)) {
						isValid = true;
					}
				}
				return isValid;
			}
		};

		// Test Parameters and test data
		final int iExposureMode = JobEditConst.EXPO_MODE_FREE;
		final boolean bEnabledXSMB = false;
		final boolean bEnabledYSMB = true;
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/ValidDev.dev";
		final String sMachineType = "H800";

		// Expected result
		final ValueWrongCheckProxy expectedResult = new ValueWrongCheckProxy(RecipeConst.VALUE_CHECK_OK);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: performCheckValueWrong()
		final ValueWrongCheckProxy result = 
				validator.performCheckValueWrong(iExposureMode, bEnabledXSMB, bEnabledYSMB, mapConsData);

		// Verification items
		assertThat(result, instanceOf(ValueWrongCheckProxy.class));
		assertThat(result.getShotNo(), is(equalTo(expectedResult.getShotNo())));
		assertThat(result.getErrorNo(), is(equalTo(expectedResult.getErrorNo())));
		assertThat(result.getErrorSetCodeList().size(), is(equalTo(expectedResult.getErrorSetCodeList().size())));
	}

	/**
	 * Invalid Test Case:
	 * Step Num X (02010) is set to 10 (Valid is <= 5)
	 * Step Num Y (02011) is set to 4 (Valid is <= 3)
	 * Expected result is Empty HashMap
	 */
	@Test
	public final void test_performCalcJobForDevice_Invalid() {
		// Test Parameters and test data
		final String sDeviceName = "TST004"; // data/console/job directory
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/TST004ER.dev";
		final String sMachineType = "H800";

		// Expected results
		final Map<String, AbstractConsoleData> mapExpected = new HashMap<String, AbstractConsoleData>();
		
		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: performCheckValueWrong()
		final Map<String, AbstractConsoleData> mapResult = validator.performCalcJobForDevice(sDeviceName, mapConsData);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult, is(equalTo(mapExpected)));
	}

	/**
	 * Valid Test Case:
	 * Step Num X (02010) is set to 4 (Valid is <= 5)
	 * Step Num Y (02011) is set to 2 (Valid is <= 3)
	 * Expected result is HashMap contains valid data
	 */
	@Test
	public final void test_performCalcJobForDevice_Valid() {
		// Test Parameters and test data
		final String sDeviceName = "TST004"; // data/console/job directory
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/TST004.dev";
		final String sMachineType = "H800";

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: performCheckValueWrong()
		final Map<String, AbstractConsoleData> mapResult = validator.performCalcJobForDevice(sDeviceName, mapConsData);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapConsData.size())));
		assertThat(mapResult, is(equalTo(mapConsData)));
	}

	/**
	 * Machine Type: H800
	 * 
	 * Invalid Test Case:
	 * Exposure Area Left (020C1): 375 < Exposure Area Right (020C4): 400
	 * Expected error message: "There is no Exposure Area!!!"
	 * Expected error setcodes: 020C1 and 020C4
	 */
	@Test
	public final void test_validateDeviceDataRecipe_checkConsistency_Invalid_001() {
		// Test Parameters and test data
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/Error1.dev";
		final String sMachineType = "H800";
		final String sDeviceName = "Error.dev"; // placeholder only
		final String sProcessName = "Error.pro"; // placeholder only

		// Expected result
		final Map<String, List<String>> mapExpected = new HashMap<String, List<String>>();
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add(JobEditConst.MASK_PATTERN_A_DEV[1]);
		listErrorSetCode.add(JobEditConst.MASK_PATTERN_A_DEV[4]);
		mapExpected.put(JobEditConst.ERROR_EXPO_AREA, listErrorSetCode);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: validateDeviceDataRecipe()
		final Map<String, List<String>> mapResult =
				validator.validateDeviceDataRecipe(mapConsData, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult.get(JobEditConst.ERROR_EXPO_AREA),
				is(equalTo(mapExpected.get(JobEditConst.ERROR_EXPO_AREA))));
		assertThat(mapResult.get(JobEditConst.ERROR_EXPO_AREA).size(),
				is(equalTo(mapExpected.get(JobEditConst.ERROR_EXPO_AREA).size())));
	}

	/**
	 * Exposure Mode: Partial
	 * Machine Type: H800
	 * 
	 * Partial Layout:
	 *  Row Alignment Position[01](02330) is set to 5 (Max: 2)
	 * 
	 * Test data: range001.dev
	 * 
	 * Expected error: "Please Check Value."
	 * Expected error setcodes: 02330
	 */
	@Test
	public final void test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_001() {
		new MockUp<ConsistencyCheckForDevice>() {
			@Mock
			public List<String> checkConsistency(final int iItemIndex,
					final Map<String, AbstractConsoleData> mapConsData) {
				final List<String> dummyList = new LinkedList<String>();
				return dummyList;
			}
			@Mock
			public Map<String, List<String>> getErrorSetCodeMap() {
				Map<String, List<String>> mapErrorMessage = new HashMap<String, List<String>>();
				return mapErrorMessage;
			}
		};
		// Test Parameters and test data
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/range001.dev";
		final String sMachineType = "H800";
		final String sDeviceName = "Error.dev"; // placeholder only
		final String sProcessName = "Error.pro"; // placeholder only

		// Expected result
		final Map<String, List<String>> mapExpected = new HashMap<String, List<String>>();
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add(JobEditConst.ALIGNMENTPOS_ALLAY[0]);
		mapExpected.put(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE, listErrorSetCode);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: validateDeviceDataRecipe()
		final Map<String, List<String>> mapResult =
				validator.validateDeviceDataRecipe(mapConsData, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE))));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size(),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size())));
	}

	/**
	 * Exposure Mode: Partial
	 * Machine Type: H800
	 * 
	 * Partial Layout:
	 * 	Column Overlap Side[01](02300) is set to 5 (Max: 2)
	 * 
	 * Test data: range002.dev
	 * 
	 * Expected error: "Please Check Value."
	 * Expected error setcodes: 02300
	 */
	@Test
	public final void test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_002() {
		new MockUp<ConsistencyCheckForDevice>() {
			@Mock
			public List<String> checkConsistency(final int iItemIndex,
					final Map<String, AbstractConsoleData> mapConsData) {
				final List<String> dummyList = new LinkedList<String>();
				return dummyList;
			}
			@Mock
			public Map<String, List<String>> getErrorSetCodeMap() {
				Map<String, List<String>> mapErrorMessage = new HashMap<String, List<String>>();
				return mapErrorMessage;
			}
		};
		// Test Parameters and test data
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/range002.dev";
		final String sMachineType = "H800";
		final String sDeviceName = "Error.dev"; // placeholder only
		final String sProcessName = "Error.pro"; // placeholder only

		// Expected result
		final Map<String, List<String>> mapExpected = new HashMap<String, List<String>>();
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add(JobEditConst.OVERLAPSIDE_COL1_SETCODE);
		mapExpected.put(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE, listErrorSetCode);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: validateDeviceDataRecipe()
		final Map<String, List<String>> mapResult =
				validator.validateDeviceDataRecipe(mapConsData, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE))));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size(),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size())));
	}

	/**
	 * Exposure Mode: FreeLayout
	 * Machine Type: H800
	 * 
	 * Free Layout(Mask Layout):
	 * 	Exposure Area[Left] (020C1) = 400 (Max: 375, Min: -375)
	 * 
	 * Test data: range003.dev
	 * 
	 * Expected error: "Please Check Value."
	 * Expected error setcodes: 020C1
	 */
	@Test
	public final void test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_003() {
		new MockUp<ConsistencyCheckForDevice>() {
			@Mock
			public List<String> checkConsistency(final int iItemIndex,
					final Map<String, AbstractConsoleData> mapConsData) {
				final List<String> dummyList = new LinkedList<String>();
				return dummyList;
			}
			@Mock
			public Map<String, List<String>> getErrorSetCodeMap() {
				Map<String, List<String>> mapErrorMessage = new HashMap<String, List<String>>();
				return mapErrorMessage;
			}
		};
		// Test Parameters and test data
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/range003.dev";
		final String sMachineType = "H800";
		final String sDeviceName = "Error.dev"; // placeholder only
		final String sProcessName = "Error.pro"; // placeholder only

		// Expected result
		final Map<String, List<String>> mapExpected = new HashMap<String, List<String>>();
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add("020C1");
		mapExpected.put(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE, listErrorSetCode);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: validateDeviceDataRecipe()
		final Map<String, List<String>> mapResult =
				validator.validateDeviceDataRecipe(mapConsData, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE))));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size(),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size())));
	}

	/**
	 * Exposure Mode: FreeLayout
	 * Machine Type: H800
	 * 
	 * Free Layout(Plate Layout):
	 * 	Step Position [X], Step 1: (02030) = 1200 (Max: 1010, Min: -1010)
	 * 
	 * Test data: range004.dev
	 * 
	 * Expected error: "Please Check Value."
	 * Expected error setcodes: 02030
	 */
	@Test
	public final void test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_004() {
		new MockUp<ConsistencyCheckForDevice>() {
			@Mock
			public List<String> checkConsistency(final int iItemIndex,
					final Map<String, AbstractConsoleData> mapConsData) {
				final List<String> dummyList = new LinkedList<String>();
				return dummyList;
			}
			@Mock
			public Map<String, List<String>> getErrorSetCodeMap() {
				Map<String, List<String>> mapErrorMessage = new HashMap<String, List<String>>();
				return mapErrorMessage;
			}
		};
		// Test Parameters and test data
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/range004.dev";
		final String sMachineType = "H800";
		final String sDeviceName = "Error.dev"; // placeholder only
		final String sProcessName = "Error.pro"; // placeholder only

		// Expected result
		final Map<String, List<String>> mapExpected = new HashMap<String, List<String>>();
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add(DeviceDataRecipeValidator.FreeLayoutPlateSETCODE.STEP_POS_X.getName());
		mapExpected.put(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE, listErrorSetCode);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: validateDeviceDataRecipe()
		final Map<String, List<String>> mapResult =
				validator.validateDeviceDataRecipe(mapConsData, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE))));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size(),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size())));
	}

	/**
	 * Exposure Mode: Normal
	 * Machine Type: H800
	 * 
	 * Plate Size X (2000E) = 2600 (Max: 2500, Min: 650)
	 * 
	 * Test data: range005.dev
	 * 
	 * Expected error: "Please Check Value."
	 * Expected error setcodes: 2000E
	 */
	@Test
	public final void test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_005() {
		new MockUp<ConsistencyCheckForDevice>() {
			@Mock
			public List<String> checkConsistency(final int iItemIndex,
					final Map<String, AbstractConsoleData> mapConsData) {
				final List<String> dummyList = new LinkedList<String>();
				return dummyList;
			}
			@Mock
			public Map<String, List<String>> getErrorSetCodeMap() {
				Map<String, List<String>> mapErrorMessage = new HashMap<String, List<String>>();
				return mapErrorMessage;
			}
		};
		// Test Parameters and test data
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/range005.dev";
		final String sMachineType = "H800";
		final String sDeviceName = "Error.dev"; // placeholder only
		final String sProcessName = "Error.pro"; // placeholder only

		// Expected result
		final Map<String, List<String>> mapExpected = new HashMap<String, List<String>>();
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add(RecipeConst.SET_CODE_PLATE_SIZE_X);
		mapExpected.put(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE, listErrorSetCode);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: validateDeviceDataRecipe()
		final Map<String, List<String>> mapResult =
				validator.validateDeviceDataRecipe(mapConsData, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE))));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size(),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size())));
	}

	/**
	 * Exposure Mode: Normal
	 * Machine Type: H800
	 * 
	 * BDC Offset [Step 1:X](22620) = 99999.999 (Max: 999.999, Min: -999.999)
	 * 
	 * Test data: range006.dev
	 * 
	 * Expected error: "Please Check Value."
	 * Expected error setcodes: 22620
	 */
	@Test
	public final void test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_006() {
		new MockUp<ConsistencyCheckForDevice>() {
			@Mock
			public List<String> checkConsistency(final int iItemIndex,
					final Map<String, AbstractConsoleData> mapConsData) {
				final List<String> dummyList = new LinkedList<String>();
				return dummyList;
			}
			@Mock
			public Map<String, List<String>> getErrorSetCodeMap() {
				Map<String, List<String>> mapErrorMessage = new HashMap<String, List<String>>();
				return mapErrorMessage;
			}
		};
		// Test Parameters and test data
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/range006.dev";
		final String sMachineType = "H800";
		final String sDeviceName = "Error.dev"; // placeholder only
		final String sProcessName = "Error.pro"; // placeholder only

		// Expected result
		final Map<String, List<String>> mapExpected = new HashMap<String, List<String>>();
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add(RecipeConst.BDC_OFFSET_SET_CODE_NO[3]);
		mapExpected.put(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE, listErrorSetCode);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: validateDeviceDataRecipe()
		final Map<String, List<String>> mapResult =
				validator.validateDeviceDataRecipe(mapConsData, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE))));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size(),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size())));
	}

	/**
	 * Exposure Mode: Normal
	 * Machine Type: H800
	 * 
	 * SDC Offset [Step 1 DR](223F0) = 30.000 (Max: 20.000, Min: -20.000)
	 * 
	 * Test data: range007.dev
	 * 
	 * Expected error: "Please Check Value."
	 * Expected error setcodes: 223F0
	 */
	@Test
	public final void test_validateDeviceDataRecipe_performValueRangeCheck_Invalid_007() {
		new MockUp<ConsistencyCheckForDevice>() {
			@Mock
			public List<String> checkConsistency(final int iItemIndex,
					final Map<String, AbstractConsoleData> mapConsData) {
				final List<String> dummyList = new LinkedList<String>();
				return dummyList;
			}
			@Mock
			public Map<String, List<String>> getErrorSetCodeMap() {
				Map<String, List<String>> mapErrorMessage = new HashMap<String, List<String>>();
				return mapErrorMessage;
			}
		};
		// Test Parameters and test data
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/range007.dev";
		final String sMachineType = "H800";
		final String sDeviceName = "Error.dev"; // placeholder only
		final String sProcessName = "Error.pro"; // placeholder only
		
		// Expected result
		final Map<String, List<String>> mapExpected = new HashMap<String, List<String>>();
		final List<String> listErrorSetCode = new LinkedList<String>();
		listErrorSetCode.add(RecipeConst.SDC_OFFSET_SET_CODE_NO[0]);
		mapExpected.put(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE, listErrorSetCode);

		// Load test data
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapConsData = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: validateDeviceDataRecipe()
		final Map<String, List<String>> mapResult =
				validator.validateDeviceDataRecipe(mapConsData, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE))));
		assertThat(mapResult.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size(),
				is(equalTo(mapExpected.get(JobEditConst.PLEASE_CHECK_VALUE_MESSAGE).size())));
	}

	/**
	 * Valid Test Case:
	 * Step Num X (02010) is set to 4 (Valid is <= 5)
	 * Step Num Y (02011) is set to 2 (Valid is <= 3)
	 * Expected result is HashMap contains valid data
	 */
	@Test
	public final void test_validateDeviceDataRecipe_performCalcJobForDevice_Valid_001() {
		new MockUp<ConsistencyCheckForDevice>() {
			@Mock
			public List<String> checkConsistency(final int iItemIndex,
					final Map<String, AbstractConsoleData> mapConsData) {
				final List<String> dummyList = new LinkedList<String>();
				return dummyList;
			}
			@Mock
			public Map<String, List<String>> getErrorSetCodeMap() {
				Map<String, List<String>> mapErrorMessage = new HashMap<String, List<String>>();
				return mapErrorMessage;
			}
		};
		// Test Parameters and test data
		final String sDeviceName = "calcjob1"; // data/console/job directory
		final String sProcessName = "calcjob1"; //placeholder only
		final String sDataFileName = "recipe_consistency_check_testdata/DeviceDataRecipeValidatorTestData/calcjob1.dev";
		final String sMachineType = "H800";

		// Expected result
		final Map<String, ConsBase> mapConsBaseData =
				ConsoleDataUtility.loadConsoleDataMap(getClass(), ConsoleDataType.Device, sDataFileName, sMachineType);
		// Convert to ConsBase to AbstractConsoleData
		final Map<String, AbstractConsoleData> mapExpected = _convConsoleDataToAbstractConsoleData(mapConsBaseData);

		// Instantiate class under test: DeviceDataRecipeValidator
		final DeviceDataRecipeValidator validator = new DeviceDataRecipeValidator();

		// Execute function under test: performCheckValueWrong()
		final Map<String, List<String>> mapResult =
				validator.validateDeviceDataRecipe(mapExpected, sDeviceName, sProcessName);

		// Verification items
		assertThat(mapResult.size(), is(equalTo(mapExpected.size())));
		assertThat(mapResult, is(equalTo(mapExpected)));
	}

	/**
	 * ConsBase��AbstractConsoleData�ɕϊ��B
	 *
	 * @param mapConsData ConsBase�}�b�v
	 * @return AbstractConsoleData�}�b�v
	 */
	private Map<String, AbstractConsoleData> _convConsoleDataToAbstractConsoleData(
			final Map<String, ConsBase> mapConsData) {
		final Map<String, AbstractConsoleData> mapAbstractConsoleData = new HashMap<String, AbstractConsoleData>();

		for (final ConsBase consBase : mapConsData.values()) {
			mapAbstractConsoleData.put(consBase.getName(), ConsoleDataUtils.getConsoleData(consBase));
		}

		return mapAbstractConsoleData;
	}
}
